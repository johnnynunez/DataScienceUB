db.createUser(
	{
		user:"admin",
		pwd:"xRCYxexRUbBS8oJ9",
		roles: [
			{
				role:"readWrite",
				db:"TweetBigData"
			}
		]
	}
)