Image is in docker hub
https://hub.docker.com/r/johnnync13/tweetbigdata/ or https://hub.docker.com/r/johnnync13/tweetbigdata/tags

I used:
docker build -t johnnync13/tweetbigdata:v1 -f Dockerfile .
docker push johnnync13/tweetbigdata:v1

OR

To run:
docker-compose up 