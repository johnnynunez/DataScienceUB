import json
import pymongo
from twython import TwythonStreamer

# Enter your keys/secrets as strings in the following fields
credentials = {}
credentials['CONSUMER_KEY'] = "whMxJqGhQc0CQh7s6rOa2bcDu"
credentials['CONSUMER_SECRET'] = "RDOnlpeookyDYlSgAf6deqqL4lZVa0BangNslTIvZbD04bgvZ2"
credentials['ACCESS_TOKEN'] = "3430665604-vLqyZxJVaBPTPNfGf7VdNKzp9at58dDroZaM7BD"
credentials['ACCESS_SECRET'] = "MpEGXV6fIqbLwE8uJVj1xKrosSgBcPW0Afluyj5D2qdKt"

# MongoDB Credentials
credentials['MONGOPASS'] = "xRCYxexRUbBS8oJ9"
credentials['MONGOUSER'] = "admin"
credentials['MONGODB'] = "TweetBigData"

# Filter out unwanted data


def process_tweet(tweet):
    d = {}
    d['hashtags'] = [hashtag['text']
        for hashtag in tweet['entities']['hashtags']]
    d['user'] = tweet['user']
    d['created_at'] = tweet['created_at']
    d['geo'] = tweet['geo']
    d['reply_count'] = tweet['reply_count']
    d['retweet_count'] = tweet['retweet_count']
    d['favorite_count'] = tweet['favorite_count']
    d['id'] = tweet['id_str']
    d['in_reply_to_status_id'] = tweet['in_reply_to_status_id_str']
    d['in_reply_to_user_id_str'] = tweet['in_reply_to_user_id_str']
    return d

# Database and collection creation
def create_database(url):
    try:
        conn = pymongo.MongoClient(url)
    except pymongo.errors.ConnectionFailure as e:
            print("Could not connect to MongoDB: %s" % e)
    db=conn["TweetBigData"]
    return db['Tweets']

def get_url():
    return "mongodb://"+credentials['MONGOUSER']+":"+credentials['MONGOPASS']+"@mongodb:27017/"+credentials["MONGODB"]+"?authSource=admin&readPreference=primary&appname=TweetBigData%20Compass&ssl=false"

# Create a class that inherits TwythonStreamer
class MyStreamer(TwythonStreamer):
    
    collection = create_database(get_url())

    count=0
    # Received data
    def on_success(self, data):

        # Only collect tweets in English
        if data['lang'] == 'en':
            tweet_data=process_tweet(data)
            # self.save_to_file(tweet_data)
            self.save_to_db(tweet_data)
            self.count += 1
            if(self.count % 100 == 0):
                print("tweet received: "+str(self.count))


    # Problem with the API
    def on_error(self, status_code, data, headers):
        print(status_code, data, headers)
        self.disconnect()

    # Save each tweet to a file
    def save_to_file(self, tweet):
        with open('bitcoin_tweet.json', 'a') as fp:
            json.dump(tweet, fp)
            fp.write("\n")
            
    def save_to_db(self, tweet):
        self.collection.insert_one(tweet)


# Instantiate from our streaming class
stream=MyStreamer(credentials['CONSUMER_KEY'], credentials['CONSUMER_SECRET'],
                    credentials['ACCESS_TOKEN'], credentials['ACCESS_SECRET'])
# Start the stream
stream.statuses.filter(track = 'bitcoin')

# Stop execution anytime by stoping the cell execution
