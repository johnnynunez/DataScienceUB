from sklearn.datasets import load_iris
import requests
import pandas as pd
from sklearn.utils import shuffle
from sklearn.linear_model import LogisticRegression
from datetime import datetime, timedelta

import airflow
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.models import Variable
import pickle



config = Variable.get("config_variables",deserialize_json=True)

MODEL_NAME = config["model_name"]
TRAIN_DATA_URL = config["train_data"]
PREDICT_URL = config["predict_data"]
TRAIN_NAME = config["train_name"]


default_args = {
    'owner': 'Johnny Nunez',
    'start_date': airflow.utils.dates.days_ago(1),
    'depends_on_past': False,
    'email': ['jnunezca11@alumnes.ub.edu'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

def get_data_train():
    """ Get the training data from the url """
    urls = requests.get(TRAIN_DATA_URL).text.split("\n")
    train = pd.DataFrame()
    for url in urls:
        train = pd.concat([train,pd.read_csv(url)])
    train.to_csv("./"+TRAIN_NAME,index=None)


def get_data_test():
    """ Get the test data from the url """
    pd.read_csv(PREDICT_URL).to_csv("./"+PREDICT_URL.split("/")[-1],index=None)

def train():
    #Read the train data
    data = pd.read_csv("./"+TRAIN_NAME)
    
    #Separate target variable
    X = data.drop(["Species"],axis=1).values
    y = data[["Species"]]
    X_new, y_new = shuffle(X, y, random_state=0)

    n_samples_train = int(config["n_samples"])

    X_train = X_new[:n_samples_train, :]
    y_train = y_new[:n_samples_train]

    X_test = X_new[n_samples_train:, :]
    y_test = y_new[n_samples_train:]

    #Fit logistic regression model
    clf = LogisticRegression(max_iter=150)
    clf.fit(X_train, y_train)

    #Save the model with the specified name
    with open(MODEL_NAME, 'wb') as f:
        pickle.dump(clf, f)

def predict():
    with open("./"+MODEL_NAME, 'rb') as f:
        clf_loaded = pickle.load(f)

    #Load the final prediction file name
    PREDICT_NAME = config["predict_name"]

    #Create a new dataframe which contains the final predictions
    pd.DataFrame({"Predicted Specie":clf_loaded.predict(
        pd.read_csv(PREDICT_URL.split("/")[-1]))}
    ).to_csv("./"+PREDICT_NAME,index=None)

    #Successful message
    print("Predicted the species:\n", pd.read_csv("./"+PREDICT_NAME))


with DAG("my_dag_johnny", default_args = default_args, schedule_interval="0 20 * * MON", catchup=False) as dag:
    #Tasks
    get_data_train = PythonOperator(task_id="get_data_train",python_callable=get_data_train)
    train_Model = PythonOperator(task_id="training_task",python_callable=train)
    get_data_test = PythonOperator(task_id="get_data_test",python_callable=get_data_test)
    predict_task = PythonOperator(task_id="predict_task",python_callable=predict)

    get_data_train >> train_Model >> predict_task
    get_data_test >> predict_task