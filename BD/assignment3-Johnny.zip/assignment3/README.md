1. I download docker-compose for airflow
2. I create the Dockerfile to install dependencies and I put it in the airflow docker-compose.yml
```
docker build . -f Dockerfile --pull --tag myimage:0.0.1
```
3. docker-compose build 
4. docker-compose up airflow-init
5. docker-compose up
6. Then I upload variables to airflow webserver 
7. I run the script


