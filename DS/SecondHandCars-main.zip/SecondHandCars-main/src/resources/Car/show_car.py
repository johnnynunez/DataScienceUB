from db import mongo
from flask_restful import Resource


class ShowCar(Resource):
    def get(self):
        try:
            dic_cars = [car for car in mongo.db.CarsCollection.find()]
            print(f"{len(dic_cars)} cars were found")
            return dic_cars, 200
        except:
            return {"message": "Internal server error"}, 500
