from db import mongo
from flask import request
from flask_restful import Resource
import re

class SearchCar(Resource):
    def get(self):
        # function predict is called at each request
        try:
            print("[+] request received")
            # get the data from the request and put ir under the right format
            search = request.args.get('Search')
            print(search)
            all_dic_cars = [car for car in mongo.db.CarsCollection.find()]
            image = ['https://www.flexicar.es/media/default.jpg','https://www.flexicar.es/images/generic/coming_soon.jpg']
            filt_dic_cars = [car for car in all_dic_cars if car['Image'] not in image]
            #Return the last 100 cars added with image:
            filt_dic_cars = list(reversed(filt_dic_cars))[:100]
            dic_cars = [car for car in filt_dic_cars if re.search(search.lower(), car['Make'].lower()) or re.search(search.lower(), car['Model'].lower()) or re.search(search.lower(), car['Location'].lower()) or re.search(search.lower(), car['Fuel'].lower()) or re.search(search.lower(), car['Transmission'].lower()) or re.search(search.lower(), car['Color'].lower()) or re.search(search.lower(), car['Body_type'].lower())]
            #dic_cars = [car for car in mongo.db.CarsCollection.find({"$or": [
            #     {'Make': {'$regex': search, '$options': 'i'}}, {'Model': {'$regex': search, '$options': 'i'}},
            #     {'Location': {'$regex': search, '$options': 'i'}}, {'Fuel': {'$regex': search, '$options': 'i'}},
            #     {'Transmission': {'$regex': search, '$options': 'i'}}, {'Color': {'$regex': search, '$options': 'i'}},
            #     {'Body_type': {'$regex': search, '$options': 'i'}}]})]
            return dic_cars, 200
        except:
            return {"message": "Internal server error"}, 500
