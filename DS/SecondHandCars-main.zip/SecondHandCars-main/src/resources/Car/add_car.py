from db import mongo
from flask import request
from flask_restful import Resource


class AddCar(Resource):
    def post(self):
        # function predict is called at each request
        try:
            print("[+] request received")
            # get the data from the request and put ir under the right format
            req = request.get_json(force=True)
            # get last id mongodb and add 1
            last_id = mongo.db.CarsCollection.find().sort("_id", -1).limit(1)[0]['_id']
            new_id = last_id + 1
            # get the data from the request
            req['_id'] = new_id
            mongo.db.CarsCollection.insert_one(req)
            print("[+] data inserted")
            return 200
        except:
            return {"message": "Internal server error"}, 500
