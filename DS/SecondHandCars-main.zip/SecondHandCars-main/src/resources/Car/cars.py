from db import mongo
from flask import request
from flask_restful import Resource


class Cars(Resource):
    def post(self):
        try:
            data = request.get_json()
            key, value = data.popitem()
            if value == None:
                dic_cars = [car[key] for car in mongo.db.CarsCollection.find().limit(10)]
            else:
                dic_cars = [car[key] for car in
                            mongo.db.CarsCollection.find({key: {'$regex': value, '$options': 'i'}}).limit(10)]
            dic_cars = list(set(dic_cars))
            print(f"{len(dic_cars)} cars were found")
            return dic_cars, 200
        except:
            return {"message": "Internal server error"}, 500
