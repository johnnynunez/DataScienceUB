import json

import pandas as pd
from src.processing.mongodb import download_collection

data = download_collection(collection='CarsCollectionNoMissings')
df = pd.DataFrame(data)

# If Make is informed but Model is not

makes = df['Make'].unique()

model_from_make = {}
for make in makes:
    df_ = df[df['Make'] == make]
    x = {make: df_['Model'].value_counts().index[0]}
    model_from_make = {**model_from_make, **x}

# If Model is informed but Make is not
make_model_vc = df[['Make', 'Model']].value_counts().reset_index()
models = df['Model']
make_from_model = {}
for model in models:
    m = make_model_vc[make_model_vc['Model'] == model]
    m = m.iloc[0, 0]
    x = {model: m}
    make_from_model = {**make_from_model, **x}

cat_vars = ['Location', 'Fuel', 'Transmission', 'Color', 'Body_type']
num_vars = ['Price', 'Mileage', 'Doors', 'Seats', 'Power', 'Age']

dummy_autocomplete = {}

for i in range(0, len(cat_vars)):
    x = {cat_vars[i]: df[cat_vars[i]].value_counts().index[0]}
    dummy_autocomplete = {**dummy_autocomplete, **x}

for i in range(0, len(num_vars)):
    x = {num_vars[i]: df[num_vars[i]].median()}
    dummy_autocomplete = {**dummy_autocomplete, **x}

df[['Make', 'Model']].value_counts()
x = {'Make': 'Seat', 'Model': 'Leon'}
dummy_autocomplete = {**dummy_autocomplete, **x}

with open('dummy_autocomplete.json', 'w') as da:
    json.dump(dummy_autocomplete, da)
    
with open('make_from_model.json', 'w') as ma:
    json.dump(make_from_model, ma)
    
with open('model_from_make.json', 'w') as ma:
    json.dump(model_from_make, ma)



