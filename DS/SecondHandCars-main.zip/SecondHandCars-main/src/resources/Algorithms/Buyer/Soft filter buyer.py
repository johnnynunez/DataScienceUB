import pickle

import numpy as np
import pandas as pd
from sklearn import preprocessing
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import OneHotEncoder

from src.processing.mongodb import download_collection

data = download_collection(collection='CarsCollectionNoMissings')
df = pd.DataFrame(data)
df.drop(['_id', 'Image'], axis=1, inplace=True)

filter_model = df['Model'].value_counts()
filter_model = filter_model[filter_model <= 15]

filter_make = df['Make'].value_counts()
filter_make = filter_make[filter_make <= 15]

df.loc[df['Model'].isin(filter_model.reset_index()['index']), 'Model'] = 'Others'
df.loc[df['Make'].isin(filter_make.reset_index()['index']), 'Make'] = 'Others'

cat_variables = df.select_dtypes(include='O').columns

df_cat = df[cat_variables]
df_num = df.drop(cat_variables, axis=1)

enc = OneHotEncoder(handle_unknown='ignore')
enc.fit(df_cat)
pickle.dump(enc, open('hot_encoder.sav', 'wb'))

df_cat = enc.transform(df_cat).toarray()

scaler = preprocessing.StandardScaler().fit(df_num)

pickle.dump(scaler, open('scaler.sav', 'wb'))

df_num_norm = scaler.transform(df_num)

df_values = np.concatenate((df_num_norm, df_cat), axis=1)

df_values[:, 0] = df_values[:, 0] * 3

nbrs = NearestNeighbors(n_neighbors=10, algorithm='ball_tree').fit(df_values)

pickle.dump(nbrs, open('KNN.sav', 'wb'))
