import json

import numpy as np
from catboost import CatBoostRegressor

Catboost_Model = CatBoostRegressor()
Catboost_Model.load_model('../Seller/Catboost_Model.cbm', format='cbm')

Catboost_NoModel = CatBoostRegressor()
Catboost_NoModel.load_model('../Seller/Catboost_NoModel.cbm', format='cbm')

with open('../Seller/car_makes_1.txt') as json_file:
    makes_1 = json.load(json_file)

with open('../Seller/car_models_1.txt') as json_file:
    models_1 = json.load(json_file)

with open('../Seller/car_makes_2.txt') as json_file:
    makes_2 = json.load(json_file)


def biggest_bargains(df):
    y = df['Price']
    X = df.drop(['Price', 'Color'], axis=1)

    prediction = np.exp(Catboost_Model.predict(X))
    df['Predicted Price'] = prediction
    df['Difference'] = df['Predicted Price'] - df['Price']
    df = df.sort_values('Difference', ascending=False)

    return df
