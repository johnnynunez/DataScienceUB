import json
import pickle

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor
from flask import jsonify
from flask import request
from flask_restful import Resource, reqparse

from src.processing.mongodb import connect_to_mongo, search_engine_one_request, search_engine_many_requests

parser = reqparse.RequestParser()
db = connect_to_mongo()

with open('src/resources/Algorithms/Seller/make_model.txt') as json_file:
    make_model = json.load(json_file)

Catboost_Model = CatBoostRegressor()
Catboost_Model.load_model('src/resources/Algorithms/Seller/Catboost_Model.cbm', format='cbm')

Catboost_NoModel = CatBoostRegressor()
Catboost_NoModel.load_model('src/resources/Algorithms/Seller/Catboost_NoModel.cbm', format='cbm')

hot_econding = pickle.load(open('src/resources/Algorithms/Buyer/hot_encoder.sav', 'rb'))
scaler = pickle.load(open('src/resources/Algorithms/Buyer/scaler.sav', 'rb'))
KNN = pickle.load(open('src/resources/Algorithms/Buyer/KNN.sav', 'rb'))

num_vars = ['Price', 'Mileage', 'Doors', 'Seats', 'Power', 'Age']
cat_vars = ['Make', 'Model', 'Location', 'Fuel', 'Transmission',
            'Color', 'Body_type']
drop_vars = ['Image', 'Difference', 'Predicted Price']
vars = ['Make', 'Location', 'Mileage', 'Fuel', 'Transmission',
         'Seats', 'Power', 'Age', 'Body_type', 'MakeModel']


def biggest_bargains(df, df_noM):
    """
    Given df request, and its corresponding df without missings, returns both df's ordered by Biggest Bargains
    """
    df_noM['MakeModel'] = df_noM['Make'] + df_noM['Model']

    X = df_noM[vars]
    X_m = X[X['MakeModel'].isin(make_model)]
    X_nm = X[~X['MakeModel'].isin(make_model)]
    X_nm.drop('MakeModel', axis=1, inplace=True)

    df.loc[df_noM['MakeModel'].isin(make_model), 'Predicted Price'] = Catboost_Model.predict(X_m)
    df.loc[~df_noM['MakeModel'].isin(make_model), 'Predicted Price'] = Catboost_NoModel.predict(X_nm)

    df['Difference'] = df['Predicted Price'] - df['Price']
    df_noM['Difference'] = df['Predicted Price'] - df['Price']

    df = df.sort_values('Difference', ascending=False)
    df_noM = df_noM.sort_values('Difference', ascending=False)

    return df, df_noM


class Buyer(Resource):

    def post(self, similar=False):
        print("[+] request received")
        # Get request JSON with all features, some empty
        req = request.get_json(force=True)
        # Get request JSON with only non-empty entries
        req_to_mongo = {}

        for x, y in req.items():
            if x not in drop_vars:
                if y != '' and y != 'NAN' and y != 'nan' and y != 'None':
                    if x in num_vars:
                        req_to_mongo[x] = float(y)
                    else:
                        req_to_mongo[x] = y

        # Get results and convert to df
        result = search_engine_one_request(db, 'CarsCollection', req_to_mongo)
        df_filt = pd.DataFrame(result)

        try:
            ids_filtered = df_filt['_id']
            result_noM = search_engine_many_requests(db, 'CarsCollectionNoMissings', ids_filtered.tolist())
            df_filt_noM = pd.DataFrame(result_noM)
        except:
            df_filt_noM = df_filt.copy()

        if df_filt.shape[0] > 0 and not similar:
            df_filt, df_filt_noM = biggest_bargains(df_filt, df_filt_noM)
            # TODO: not choose first car, create a request filling with standard values
            car_series = df_filt_noM.iloc[0, :]
            print("Not similar")

        else:
            print("Similar")
            f = open('src/resources/Algorithms/Buyer/dummy_autocomplete.json')
            most_common_attributes = json.load(f)

            f = open('src/resources/Algorithms/Buyer/make_from_model.json')
            make_from_model = json.load(f)

            f = open('src/resources/Algorithms/Buyer/model_from_make.json')
            model_from_make = json.load(f)

            if req["Make"] != '' and req["Model"] == '':
                req["Model"] = model_from_make[req["Make"]]
            elif req["Make"] == '' and req["Model"] != '':
                req["Make"] = make_from_model[req["Model"]]

            fake_request = {}
            for x, y in req.items():
                if x not in drop_vars:
                    if y != '' and y != 'NAN' and y != 'nan' and y != 'None':
                        if x in num_vars:
                            fake_request[x] = float(y)
                        else:
                            fake_request[x] = y
                    else:
                        fake_request[x] = most_common_attributes[x]

            car_series = pd.Series(fake_request)

        car_series_num = car_series[num_vars]
        car_series_cat = car_series[cat_vars]

        car_series_cat = hot_econding.transform(pd.DataFrame(car_series_cat).T).toarray()
        car_series_num_norm = scaler.transform(pd.DataFrame(car_series_num).T)
        series_values = np.concatenate((car_series_num_norm, car_series_cat), axis=1)

        # Get 10 nearest neighbours in a ordered list
        distances, indices = KNN.kneighbors(series_values)

        # Request this indices to mongo: 1-JSON query, 2-Get cars
        list_ids = indices[0].tolist()

        mongo_match = search_engine_many_requests(db, 'CarsCollection', list_ids)
        mongo_match_noM = search_engine_many_requests(db, 'CarsCollectionNoMissings', list_ids)

        knn_df = pd.DataFrame(mongo_match)
        knn_df_noM = pd.DataFrame(mongo_match_noM)
        knn_df, knn_df_noM = biggest_bargains(knn_df, knn_df_noM)
        df_f = pd.concat([df_filt, knn_df], axis=0)
        df_f.drop_duplicates(inplace=True)

        response = df_f.astype(str).to_dict(orient='records')
        print("[+] results {}".format(response))

        return response