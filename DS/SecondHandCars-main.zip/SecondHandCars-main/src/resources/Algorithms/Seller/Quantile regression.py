import pandas as pd
from catboost import CatBoostRegressor
from catboost import Pool
from sklearn.model_selection import train_test_split

from src.processing.mongodb import download_collection

data = download_collection(collection='CarsCollectionNoMissings')

df = pd.DataFrame(data)
df.drop(['Image', '_id', 'Color'], axis=1, inplace=True)

df['MakeModel'] = df['Make']+df['Model']
filter_model = df['MakeModel'].value_counts()
filter_model = filter_model[filter_model >= 5]

df.drop('Model', axis=1, inplace=True)
df1 = df[df['MakeModel'].isin(filter_model.reset_index()['index'])]
df2 = df.copy()

y1 = df1['Price']
X1 = df1.drop(['Price', 'Doors'], axis=1)

y2 = df2['Price']
X2 = df2.drop(['Price', 'Doors', 'MakeModel'], axis=1)

# Categorical positions for catboost
Categorical = list()
for col in list(X1):
    if X1[col].dtypes == 'object':
        Categorical.append(col)

Pos = list()
for col in Categorical:
    Pos.append((X1.columns.get_loc(col)))

X1_train, X1_val, y1_train, y1_val = train_test_split(X1, y1, test_size=0.20)

pool1_tr = Pool(X1_train, y1_train, cat_features=Pos)
pool1_val = Pool(X1_val, y1_val, cat_features=Pos)

params = {'depth': 6,  # Depth of the trees (values betwen 5 and 10, higher -> more overfitting)
          'l2_leaf_reg': 14,  # L2 regularization (between 3 and 20, higher -> less overfitting)
          'rsm': 0.8,  # % of features to consider in each split (lower -> faster and reduces overfitting)
          'subsample': 0.8,
          'bootstrap_type': 'MVS'}

gbrL_Model = CatBoostRegressor(iterations=10000, od_type='Iter', verbose=500,
                               objective='Quantile:alpha=0.05')

gbrL_Model.set_params(**params)

gbrL_Model.fit(X=pool1_tr,
               eval_set=pool1_val,
               early_stopping_rounds=100,
               plot=False)

gbrL_Model.save_model('gbrL_Model.cbm', pool=pool1_tr)
"""
pd.DataFrame({'feature_importance': gbrL_Model.get_feature_importance(pool1_tr),
              'feature_names': X1_val.columns}).sort_values(by=['feature_importance'],
                                                            ascending=False)
"""

gbrH_Model = CatBoostRegressor(iterations=10000, od_type='Iter', verbose=500,
                               objective='Quantile:alpha=0.95')
gbrH_Model.set_params(**params)
gbrH_Model.fit(X=pool1_tr,
               eval_set=pool1_val,
               early_stopping_rounds=100,
               plot=False)

gbrH_Model.save_model('gbrH_Model.cbm', pool=pool1_tr)

"""
pd.DataFrame({'feature_importance': gbrH_Model.get_feature_importance(pool1_tr),
              'feature_names': X1_val.columns}).sort_values(by=['feature_importance'],
                                                            ascending=False)
"""

# Categorical positions for catboost
Categorical = list()
for col in list(X2):
    if X2[col].dtypes == 'object':
        Categorical.append(col)

Pos = list()
for col in Categorical:
    Pos.append((X2.columns.get_loc(col)))

X2_train, X2_val, y2_train, y2_val = train_test_split(X2, y2, test_size=0.20)

pool2_tr = Pool(X2_train, y2_train, cat_features=Pos)
pool2_val = Pool(X2_val, y2_val, cat_features=Pos)

gbrL_NoModel = CatBoostRegressor(iterations=10000, od_type='Iter', verbose=500,
                               objective='Quantile:alpha=0.05')

gbrL_NoModel.set_params(**params)

gbrL_NoModel.fit(X=pool2_tr,
               eval_set=pool2_val,
               early_stopping_rounds=100,
               plot=False)

gbrL_NoModel.save_model('gbrL_NoModel.cbm', pool=pool2_tr)
"""
pd.DataFrame({'feature_importance': gbrL_NoModel.get_feature_importance(pool2_tr),
              'feature_names': X2_val.columns}).sort_values(by=['feature_importance'],
                                                            ascending=False)
"""

gbrH_NoModel = CatBoostRegressor(iterations=10000, od_type='Iter', verbose=500,
                               objective='Quantile:alpha=0.95')
gbrH_NoModel.set_params(**params)
gbrH_NoModel.fit(X=pool2_tr,
               eval_set=pool2_val,
               early_stopping_rounds=100,
               plot=False)

gbrH_NoModel.save_model('gbrH_NoModel.cbm', pool=pool2_tr)

"""
pd.DataFrame({'feature_importance': gbrH_Model.get_feature_importance(pool1_tr),
              'feature_names': X1_val.columns}).sort_values(by=['feature_importance'],
                                                            ascending=False)
"""




