import json

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor
from flask import jsonify
from flask import request
from flask_restful import Resource

"""Load models to predict price"""
Catboost_Model = CatBoostRegressor()
# Catboost_Model.load_model('resources/Algorithms/Seller/Catboost_Model.cbm', format='cbm')
Catboost_Model.load_model('src/resources/Algorithms/Seller/Catboost_Model.cbm', format='cbm')

Catboost_NoModel = CatBoostRegressor()
Catboost_NoModel.load_model('src/resources/Algorithms/Seller/Catboost_NoModel.cbm', format='cbm')
# Catboost_NoModel.load_model('resources/Algorithms/Seller/Catboost_NoModel.cbm', format='cbm')

"""Load models to predict uncertainty"""

gbrL_Model = CatBoostRegressor()
gbrL_Model.load_model('src/resources/Algorithms/Seller/gbrL_Model.cbm', format='cbm')

gbrH_Model = CatBoostRegressor()
gbrH_Model.load_model('src/resources/Algorithms/Seller/gbrH_Model.cbm', format='cbm')

gbrL_NoModel = CatBoostRegressor()
gbrL_NoModel.load_model('src/resources/Algorithms/Seller/gbrL_NoModel.cbm', format='cbm')

gbrH_NoModel = CatBoostRegressor()
gbrH_NoModel.load_model('src/resources/Algorithms/Seller/gbrH_NoModel.cbm', format='cbm')

with open('src/resources/Algorithms/Seller/make_model.txt') as json_file:
    make_model = json.load(json_file)


class Seller(Resource):

    def post(self):
        # function predict is called at each request
        print("[+] request received")
        # get the data from the request and put ir under the right format
        req = request.get_json(force=True)
        req["MakeModel"] = req["Make"] + req["Model"]

        pops = ["Color", "Doors", "Model"]

        for pop in pops:
            req.pop(pop, None)

        if req["MakeModel"] in make_model:
            req2 = pd.Series(req)
            prediction = Catboost_Model.predict(req2)
            lower_bound = gbrL_Model.predict(req2)
            if lower_bound > prediction:
                lower_bound = prediction
            upper_bound = gbrH_Model.predict(req2)
            if upper_bound < prediction:
                upper_bound = prediction

        else:
            req.pop("MakeModel", None)
            req2 = pd.Series(req)
            prediction = Catboost_NoModel.predict(req2)
            lower_bound = gbrL_NoModel.predict(req2)
            if lower_bound > prediction:
                lower_bound = prediction
            upper_bound = gbrH_NoModel.predict(req2)
            if upper_bound < prediction:
                upper_bound = prediction

        prediction = int(np.ceil(prediction))
        lower_bound = int(np.ceil(lower_bound))
        upper_bound = int(np.ceil(upper_bound))

        # create the response as a dict
        response = {"prediction": prediction, "lower_bound": lower_bound, "upper_bound": upper_bound}
        print("[+] results {}".format(response))

        return jsonify(response)  # return it as json
