import json
import pandas as pd
from catboost import CatBoostRegressor
from catboost import Pool
from sklearn.model_selection import train_test_split
pd.options.mode.chained_assignment = None

#from mongodb import download_collection
from src.processing.mongodb import download_collection

data = download_collection(collection='CarsCollectionNoMissings')
df = pd.DataFrame(data)
df.drop(['Image', '_id', 'Color'], axis=1, inplace=True)

df['MakeModel'] = df['Make']+df['Model']
filter_model = df['MakeModel'].value_counts()
filter_model = filter_model[filter_model >= 5]

df.drop('Model', axis=1, inplace=True)
df1 = df[df['MakeModel'].isin(filter_model.reset_index()['index'])]
df2 = df.copy()

make_model = df1['MakeModel'].unique().tolist()
locations = df['Location'].unique().tolist()

with open('make_model.txt', 'w') as outfile:
    json.dump(make_model, outfile)

with open('locations.txt', 'w') as outfile:
    json.dump(locations, outfile)

y1 = df1['Price']
X1 = df1.drop(['Price', 'Doors'], axis=1)

y2 = df2['Price']
X2 = df2.drop(['Price', 'Doors', 'MakeModel'], axis=1)



# Categorical positions for catboost
Categorical = list()
for col in list(X1):
    if X1[col].dtypes == 'object':
        Categorical.append(col)

Pos = list()
for col in Categorical:
    Pos.append((X1.columns.get_loc(col)))

params = {'objective': 'MAE',
          'depth': 7,  # Depth of the trees (values betwwen 5 and 10, higher -> more overfitting)
          'l2_leaf_reg': 15,  # L2 regularization (between 3 and 20, higher -> less overfitting)
          'rsm': 0.8,  # % of features to consider in each split (lower -> faster and reduces overfitting)
          'subsample': 0.8,
          'bootstrap_type': 'MVS'}

"""
X1_train, X1_val, y1_train, y1_val = train_test_split(X1, y1, test_size=0.20)
X1_train, X1_test, y1_train, y1_test = train_test_split(X1_train, y1_train, test_size=0.20)

pool1_tr = Pool(X1_train, y1_train, cat_features=Pos)
pool1_val = Pool(X1_val, y1_val, cat_features=Pos)

Catboost_Model1 = CatBoostRegressor(
    iterations=10000,
    od_type='Iter',
    verbose=500)

Catboost_Model1.set_params(**params)

Catboost_Model1.fit(X=pool1_tr,
                    eval_set=pool1_val,
                    early_stopping_rounds=100,
                    plot=False)

print(abs(Catboost_Model1.predict(X1_test)-y1_test).mean())

pd.DataFrame({'feature_importance': Catboost_Model1.get_feature_importance(pool1_tr),
              'feature_names': X1_val.columns}).sort_values(by=['feature_importance'],
                                                            ascending=False)
"""
X1_train, X1_val, y1_train, y1_val = train_test_split(X1, y1, test_size=0.20)

pool1_tr = Pool(X1_train, y1_train, cat_features=Pos)
pool1_val = Pool(X1_val, y1_val, cat_features=Pos)

Catboost_Model1 = CatBoostRegressor(
    iterations=10000,
    od_type='Iter',
    verbose=500)

Catboost_Model1.set_params(**params)

Catboost_Model1.fit(X=pool1_tr,
                    eval_set=pool1_val,
                    early_stopping_rounds=100,
                    plot=False)

Catboost_Model1.save_model('Catboost_Model.cbm', pool=pool1_tr)

# Categorical positions for catboost
Categorical = list()
for col in list(X2):
    if X2[col].dtypes == 'object':
        Categorical.append(col)

Pos = list()
for col in Categorical:
    Pos.append((X2.columns.get_loc(col)))

""""
X2_train, X2_val, y2_train, y2_val = train_test_split(X2, y2, test_size=0.20)
X2_train, X2_test, y2_train, y2_test = train_test_split(X2_train, y2_train, test_size=0.20)

pool2_tr = Pool(X2_train, y2_train, cat_features=Pos)
pool2_val = Pool(X2_val, y2_val, cat_features=Pos)

Catboost_Model2 = CatBoostRegressor(
    iterations=10000,
    od_type='Iter',
    verbose=500)

Catboost_Model2.set_params(**params)

Catboost_Model2.fit(X=pool2_tr,
                    eval_set=pool2_val,
                    early_stopping_rounds=100,
                    plot=False)

print(abs(Catboost_Model2.predict(X2_test)-y2_test).mean())

pd.DataFrame({'feature_importance': Catboost_Model2.get_feature_importance(pool2_tr),
              'feature_names': X2_val.columns}).sort_values(by=['feature_importance'],
                                                            ascending=False)
"""
X2_train, X2_val, y2_train, y2_val = train_test_split(X2, y2, test_size=0.20)

pool2_tr = Pool(X2_train, y2_train, cat_features=Pos)
pool2_val = Pool(X2_val, y2_val, cat_features=Pos)

Catboost_Model2 = CatBoostRegressor(
    iterations=10000,
    od_type='Iter',
    verbose=500)

Catboost_Model2.set_params(**params)

Catboost_Model2.fit(X=pool2_tr,
                    eval_set=pool2_val,
                    early_stopping_rounds=100,
                    plot=False)

Catboost_Model2.save_model('Catboost_NoModel.cbm', pool=pool2_tr)
