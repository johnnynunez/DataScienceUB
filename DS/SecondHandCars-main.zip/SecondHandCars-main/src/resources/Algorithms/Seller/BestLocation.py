import json

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor
from flask import jsonify
from flask import request
from flask_restful import Resource

Catboost_Model = CatBoostRegressor()
Catboost_Model.load_model('src/resources/Algorithms/Seller/Catboost_Model.cbm', format='cbm')
# Catboost_Model.load_model('Catboost_Model.cbm', format='cbm')

Catboost_NoModel = CatBoostRegressor()
Catboost_NoModel.load_model('src/resources/Algorithms/Seller/Catboost_NoModel.cbm', format='cbm')
# Catboost_Model.load_model('Catboost_Model.cbm', format='cbm')

with open('src/resources/Algorithms/Seller/make_model.txt') as json_file:
    make_model = json.load(json_file)

with open('src/resources/Algorithms/Seller/locations.txt') as json_file:
    locations = json.load(json_file)


def BestLocation(car):
    car_aux = car.copy()
    a = np.expand_dims(np.array(locations), 1)
    b = np.expand_dims(np.zeros(len(locations)), 1)
    res = np.concatenate((a, b), axis=1)
    car_aux["MakeModel"] = car_aux["Make"] + car_aux["Model"]

    pops = ["Color", "Doors", "Model"]

    for pop in pops:
        car_aux.pop(pop, None)

    if car_aux["MakeModel"] in make_model:
        feat = ['Make', 'Location', 'Mileage', 'Fuel', 'Transmission', 'Seats', 'Power', 'Age',
                'Body_type', 'MakeModel']
        for loc in locations:
            car_copy = car_aux.copy()
            car_copy["Location"] = loc
            car_series = pd.Series(car_copy)
            car_series = car_series[feat]
            prediction = Catboost_Model.predict(car_series)
            res[res[:, 0] == loc, 1] = prediction
    else:
        feat = ['Make', 'Location', 'Mileage', 'Fuel', 'Transmission', 'Seats', 'Power', 'Age',
                'Body_type']

        car_aux.pop("MakeModel", None)

        for loc in locations:
            car_copy = car_aux.copy()
            car_copy["Location"] = loc
            car_series = pd.Series(car_copy)
            car_series = car_series[feat]
            prediction = Catboost_NoModel.predict(car_series)
            res[res[:, 0] == loc, 1] = prediction

    #best = res[res[:, 1] == max(res[:, 1])]
    best = pd.DataFrame(res, columns=['Location', 'Price'])
    best['Price'] = best['Price'].astype(float)
    best['Price'] = best['Price'].apply(np.ceil)

    best.sort_values(['Price'], axis=0, ascending=False, inplace=True)
    best['Price'] = best['Price'].astype(int)
    top_5 = best.iloc[:5, :]
    return top_5


class Best_Location(Resource):

    def post(self):
        # function predict is called at each request
        print("[+] request received")
        # get the data from the request and put ir under the right format
        req = request.get_json(force=True)

        best_loc = BestLocation(req)

        response = dict(zip(best_loc['Location'], best_loc['Price']))

        # create the response as a dict
        #response = {"Best_Location": best_loc[0][0], "Price": best_loc[0][1]}
        print("[+] results {}".format(response))

        return jsonify(response)  # return it as json
