import itertools
import json

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor
from catboost import Pool
from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split

pd.options.mode.chained_assignment = None

data = download_collection(collection='CarsCollectionNoMissings')

df = pd.DataFrame(data)
df.drop(['Image', '_id', 'Color'], axis=1, inplace=True)



def mean_squared_error_(y_hat, y):
    y_hat = np.floor(y_hat).astype(int)
    y = y.astype(int)
    return np.sqrt(((y_hat - y) ** 2).mean())


def mean_absolute_error_(y_hat, y):
    y_hat = np.floor(y_hat).astype(int)
    y = y.astype(int)
    return abs(y_hat - y).mean()


def grid_search(X, y, n_splits, dict_params):
    keys, values = zip(*dict_params.items())
    hyperparameters_list = list()
    hyperparameters_list = [dict(zip(keys, v)) for v in itertools.product(*values)]
    skf = KFold(n_splits=n_splits, shuffle=True)
    skf.get_n_splits(X, y)
    predictoras = list(X)[1:-1]
    # Categorical positions for catboost
    Categorical = list()
    for col in list(X):
        if X[col].dtypes == 'object':
            Categorical.append(col)
    Pos = list()
    for col in Categorical:
        Pos.append((X.columns.get_loc(col)))
    statistics = np.empty([len(hyperparameters_list), 3])
    stats_kfold = np.empty([len(hyperparameters_list), n_splits])
    j = 0
    predictions = np.zeros([X.shape[0], len(hyperparameters_list)])
    for hyperparameters in hyperparameters_list:
        pred_hyper = np.empty(X.shape[0])
        stat_hyper = np.empty([n_splits])
        i = 0
        for train_index, test_index in skf.split(X, y):
            X_train, X_test = X.iloc[train_index, :], X.iloc[test_index, :]
            y_train, y_test = y[train_index], y[test_index]
            X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.20)
            pool_tr = Pool(X_train, y_train, cat_features=Pos)
            pool_val = Pool(X_val, y_val, cat_features=Pos)
            model_catboost = CatBoostRegressor(
                iterations=10000,  # Very high value, to find the optimum
                od_type='Iter',  # Overfitting detector set to "iterations"
                verbose=False)  # Shows train/test metric every "verbose" trees
            model_catboost.set_params(**hyperparameters)
            model_catboost.fit(X=pool_tr,
                               eval_set=pool_val,
                               early_stopping_rounds=100,
                               plot=False)
            y_test_hat = model_catboost.predict(X_test)
            pred_hyper[test_index] = y_test_hat
            predictions[test_index, j] = y_test_hat
            stat_hyper[i] = mean_absolute_error_(y_test_hat, y_test)
            stats_kfold[j, i] = stat_hyper[i]
            i = i + 1

        statistics[j, 0] = mean_absolute_error_(pred_hyper, y)  # ROC AUC general
        statistics[j, 1] = np.mean(stat_hyper)  # ROC AUC mig
        statistics[j, 2] = np.std(stat_hyper)  # ROC AUC desv est

        j = j + 1
    return statistics, hyperparameters_list, stats_kfold, predictions


# "Technical" parameters of the model:
params_grid_search = {'objective': ['MAE'],  # , 'MAE'
                      'depth': [4, 5],  #
                      'l2_leaf_reg': [14, 15],  # , 15
                      'rsm': [0.5, 1],  # , 0.8
                      'subsample': [0.9],  # , 0.6
                      'bootstrap_type': ['Bernoulli']}  # , 'MVS'

stat, hp_list, stats_general, pred = grid_search(X=X1, y=y1, n_splits=10, dict_params=params_grid_search)

for i in range(0, len(stat)):
    stat[i, 2] = np.std(stats_general[i])
stat_pd = pd.DataFrame(stat, columns=['MSE', 'mean_MSE', 'STD'])
fdf = pd.DataFrame(hp_list).join(stat_pd)
fdf.sort_values('MSE', ascending=True)

# "Technical" parameters of the model:
params_grid_search_2 = {'objective': ['MAE'],  # , 'MAE'
                        'depth': [3, 4, 6],  #
                        'l2_leaf_reg': [13, 14, 15],  # , 15
                        'rsm': [0.5, 0.75, 1],  # , 0.8
                        'subsample': [0.6, 0.8, 1],  # , 0.6
                        'bootstrap_type': ['Bernoulli', 'MVS']}  # , 'MVS'

stat, hp_list, stats_general, pred = grid_search(X=X1, y=y1, n_splits=10, dict_params=params_grid_search_2)

for i in range(0, len(stat)):
    stat[i, 2] = np.std(stats_general[i])

stat_pd = pd.DataFrame(stat, columns=['MSE', 'mean_MSE', 'STD'])
fdf = pd.DataFrame(hp_list).join(stat_pd)
fdf.sort_values('MSE', ascending=True)

# "Technical" parameters of the model:
params_grid_search_3 = {'objective': ['MAE'],  # , 'MAE'
                        'depth': [6, 7, 8],  #
                        'l2_leaf_reg': [14],  # , 15
                        'rsm': [0.8],  # , 0.8
                        'subsample': [0.8],  # , 0.6
                        'bootstrap_type': ['MVS']}  # , 'MVS'

stat, hp_list, stats_general, pred = grid_search(X=X1, y=y1, n_splits=10, dict_params=params_grid_search_3)

for i in range(0, len(stat)):
    stat[i, 2] = np.std(stats_general[i])

stat_pd = pd.DataFrame(stat, columns=['MSE', 'mean_MSE', 'STD'])
fdf = pd.DataFrame(hp_list).join(stat_pd)
fdf.sort_values('MSE', ascending=True)

model_Make = CatBoostRegressor(
    iterations=10000,  # Very high value, to find the optimum
    od_type='Iter',  # Overfitting detector set to "iterations"
    verbose=250)  # Shows train/test metric every "verbose" trees

# Final parameters for the model with Car model as a feature. We will use the same for the other model
# Although in the future it should be performed another cross val
params = {'objective': 'MAE',
          'depth': 7,  # Depth of the trees (values betwwen 5 and 10, higher -> more overfitting)
          'l2_leaf_reg': 14,  # L2 regularization (between 3 and 20, higher -> less overfitting)
          'rsm': 0.8,  # % of features to consider in each split (lower -> faster and reduces overfitting)
          'subsample': 0.8,
          'bootstrap_type': 'MVS'}
