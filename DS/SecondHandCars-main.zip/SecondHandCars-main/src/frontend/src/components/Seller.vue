<template>
  <div class="general">
    <div class="center">
      <section id="content">
        <p></p>
        <h6 class="subheader"> SELL YOUR CAR</h6>
        <v-form @submit.prevent="showCar">
          <v-container>
            <v-row>
              <v-col cols="12" md="4">
                <label>Make</label>
                <div class="form-group">
                  <v-autocomplete id='Make' v-model="carForm.Make" :items="listMake"
                                  :search-input.sync="searchMake" label="Make" name="Make" persistent-hint rounded
                                  class="center" required type="text"></v-autocomplete>
                </div>
                <div class="form-group">
                  <label>Model</label>
                  <v-autocomplete id='Model' v-model="carForm.Model" :items="listModel"
                                  :search-input.sync="searchModel" label="Model" name="Model" persistent-hint
                                  required rounded></v-autocomplete>
                </div>
              </v-col>
              <v-col cols="12" md="4">
                <label for="Fuel">Fuel Type</label>
                <div id="Fuel" class="form-group radiobuttons">
                  <input v-model="carForm.Fuel" name="Fuel" type="radio" value="Petrol"/> Petrol
                  <input v-model="carForm.Fuel" name="Fuel" type="radio" value="Diesel"/> Diesel
                  <input v-model="carForm.Fuel" name="Fuel" type="radio" value="Gas"/> Gas
                  <br>
                  <input v-model="carForm.Fuel" name="Fuel" type="radio" value="Hybrid"/> Hybrid
                  <input v-model="carForm.Fuel" name="Fuel" type="radio" value="Electric"/> Electric
                  <br>
                </div>

                <div class="form-group radiobuttons">
                  <label for="Automatic">Transmission</label>
                  <br>
                  <input id="Automatic" v-model="carForm.Transmission" name="Transmission"
                         type="radio" value="Automatic"/>
                  Automatic
                  <br>
                  <input id="Manual" v-model="carForm.Transmission" name="Transmission" type="radio"
                         value="Manual"/>
                  Manual
                </div>
              </v-col>
              <v-col cols="12" md="4">
                <div class="form-group">
                  <label>Doors</label>
                  <v-slider id='Doors' v-model="carForm.Doors" thumb-label="always" value="4" max="5" min="2"
                            required style="color:#09a330"></v-slider>
                </div>
                <div class="form-group">
                  <label>Seats</label>
                  <v-slider id='Seats' v-model="carForm.Seats" max="9" min="1" value="4" required thumb-label="always">
                  </v-slider>
                </div>
              </v-col>
              <v-col cols="12" md="4">
                <div class="form-group">
                  <label for="Power">Power</label>
                  <input id='Power' v-model="carForm.Power" name="Power" required type="text"/>
                </div>
              </v-col>
              <v-col cols="12" md="4">
                <div class="form-group">
                  <label for="Location">Location</label>
                  <input id='Location' v-model="carForm.Location" name="Location" required type="text"/>
                </div>
              </v-col>
              <v-col cols="12" md="4">
                <div class="form-group">
                  <label for="Mileage">Mileage</label>
                  <input id='Mileage' v-model="carForm.Mileage" name="Mileage" required type="text"/>
                </div>
              </v-col>
              <v-col cols="12" md="4">
                <div class="form-group">
                  <label for="Age">Age</label>
                  <input id='Age' v-model="carForm.Age" name="Age" required type="text"/>
                </div>

              </v-col>
              <v-col cols="12" md="4">
                <div class="form-group">
                  <label for="Body_type">Body Type</label>
                  <input id='Body_type' v-model="carForm.Body_type" name="Body_type" required type="text"/>
                </div>
                <v-btn color="error" @click="resetForm">Reset Form</v-btn>
              </v-col>
              <v-col cols="12" md="4">
                <div class="form-group">
                  <label for="Color">Color</label>
                  <input id='Color' v-model="carForm.Color" name="Color" required type="text"/>
                </div>
                <div class="clearfix"></div>
                <v-btn color="success" type="submit" value="Request">Send</v-btn>
              </v-col>
            </v-row>
          </v-container>
        </v-form>
      </section>
    </div>
    <div class="center">
      <SidebarComponent></SidebarComponent>
      <div class="clearfix"></div>
    </div>
  </div>
</template>

<script>

import SidebarComponent from './MainPage/SidebarComponent'
import axios from 'axios'

// eslint-disable-next-line no-unused-vars
// let api = 'http://127.0.0.1:5000/'
// let api = 'https://secondhand-cars.herokuapp.com/'
let api = 'https://secondhand-cars-stage.herokuapp.com/'

export default {
  name: 'Seller',
  components: {
    SidebarComponent
  },
  data () {
    return {
      carForm: {
        Make: '',
        Model: '',
        Location: '',
        Mileage: '',
        Fuel: '',
        Transmission: '',
        Color: '',
        Doors: '',
        Seats: '',
        Power: '',
        Age: '',
        Body_type: ''
      },
      mensaje: '',
      searchMake: '',
      searchModel: '',
      searchLocation: '',
      searchMileage: '',
      searchFuel: '',
      searchTransmission: '',
      searchColor: '',
      searchDoors: '',
      searchSeats: '',
      searchPower: '',
      searchAge: '',
      searchBody_type: '',
      listMake: [],
      listModel: []
    }
  },
  methods: {
    resetForm () {
      this.carForm = {
        Make: '',
        Model: '',
        Location: '',
        Mileage: '',
        Fuel: '',
        Transmission: '',
        Color: '',
        Doors: '',
        Seats: '',
        Power: '',
        Age: '',
        Body_type: ''
      }
    },
    showCar () {
      axios
        .post(api + 'seller', this.carForm)
        .then((response) => {
          console.log(response)
          this.mensaje = response.data
          this.$store.dispatch('storeCars', this.carForm)
          this.$store.dispatch('storePrediction', this.mensaje)
          this.$router.push('/ShowCar')
        })
        .catch((error) => {
          console.log(error)
        })
    },
    getMake () {
      axios.post(api + 'cars', {'Make': this.searchMake})
        .then((response) => {
          this.listMake = response.data
          console.log('ES ESTE LOG: ' + this.carForm.Make)
        })
        .catch((error) => {
          console.log(error)
        })
    },
    getModel () {
      axios.post(api + 'cars', {'Model': this.searchModel})
        .then((response) => {
          this.listModel = response.data
          console.log('ES ESTE LOG: ' + this.carForm.Model)
        })
        .catch((error) => {
          console.log(error)
        })
    },
    getLocation () {
      axios.post(api + 'cars', {'Location': this.searchLocation})
        .then((response) => {
          this.listLocation = response.data
          console.log('ES ESTE LOG: ' + this.carForm.Location)
        })
        .catch((error) => {
          console.log(error)
        })
    }
  },
  watch: {
    searchMake () {
      this.getMake()
    },
    searchModel () {
      this.getModel()
    }
  }
}
</script>
