<template>
  <div class="general">
    <div class="center">
      <section id="content">
        <p></p>
        <h6 class="subheader"> CARS </h6>
        <i>Matching your request and similar, ordered by biggest bargains</i>
        <!--Listado articulos-->
        <div id="articles" v-for="car in cars" :key="car.id">
          <article id="article-template" class="article-item">
            <div class="image-wrap">
              <img
                alt="No image found" @error="$event.target.src='https://www.3djuegos.com/files_foros/2k/2kfq.jpg'"
                v-bind:src="car.Image"/>
            </div>
            <h2>{{ car.Make }}</h2>
            <div style="margin-top:-5px;font-style:italic;margin-bottom:10px;">{{ car.Model }}</div>
            <div style="font-weight:bold;font-size:15px;">
              {{ car.Price }} €
            </div>
            <br>
            <button @click.prevent="moreInfo(car)" class="btn btn-success" type="submit">More info +</button>
            <div class="clearfix"></div>
          </article>
        </div>
        <br>
        <i>Showing {{ numberCars }}/{{ totalNumber }} cars</i>
        <br>
        <br>
      </section>
    </div>
    <div class="center">
      <aside id="sidebar" style="margin-top:100px">
        <h2 class="subheader"> Filters: </h2>
        <label for="Price_min">Price Min €:</label>
        <input id='Price_min' v-model="filteringForm.Price_min" name="Price_min"  required type="text" placeholder="1000€"/>
        <label for="Price_max">Price Max €:</label>
        <input id='Price_max' v-model="filteringForm.Price_max" name="Price_max" required type="text" placeholder="2000€"/>
        <label>Mileage Km</label>
        <v-select
          v-model="filteringForm.Mileage"
          :items="itemsMileage"
          label="Mileage Km"
        ></v-select>
        <label>Doors</label>
        <v-slider id='Doors' v-model="filteringForm.Doors" thumb-label="always" value="4" max="5" min="2"
                  required style="color:#09a330"></v-slider>
        <label>Seats</label>
        <v-slider id='Seats' v-model="filteringForm.Seats" thumb-label="always" value="4" max="5" min="2" placeholder="4"
                  required style="color:#09a330"></v-slider>
        <label>Power CV</label>
        <v-select v-model="filteringForm.Power"
          :items="itemsPower"
          label="Power CV"
        ></v-select>
        <label>Age</label>
        <v-select
          v-model="filteringForm.Age"
          :items="itemsAge"
          label="Age"
        ></v-select>
        <label for="Location">Location</label>
        <input id='Location' v-model="filteringForm.Location" name="Location" required type="text" placeholder="Barcelona"/>

      </aside>
      <div class="clearfix"></div>
    </div>
  </div>
</template>

<script>

import axios from 'axios'

// eslint-disable-next-line no-unused-vars
// let api = 'http://127.0.0.1:5000/'
// let api = 'https://secondhand-cars.herokuapp.com/'
let api = 'https://secondhand-cars-stage.herokuapp.com/'

export default {
  name: 'Buyer',
  data () {
    return {
      cars: [],
      allCars: [],
      readMore: {},
      numberCars: 10,
      totalNumber: '...',
      keyword: '',
      itemsMileage: [{text: '<25.000 Km', value: 25000}, {text: '<50.000 Km', value: 50000}, {
        text: '<75.000 Km',
        value: 75000
      }, {text: '<100.000 Km', value: 100000}, {text: '<150.000 Km', value: 150000}, {
        text: '<200.000 Km',
        value: 200000
      }, {text: '>200.000 Km', value: 200001}],
      itemsPower: [{text: '<75 CV', value: 75}, {text: '<100 CV', value: 100}, {
        text: '<125 CV',
        value: 125
      }, {text: '<150 CV', value: 150}, {text: '<200 CV', value: 200}, {text: '>200 CV', value: 201}],
      itemsAge: [{text: '<2 Years', value: 2}, {text: '<5 Years', value: 5}, {
        text: '<10 Years',
        value: 10
      }, {text: '>10 Years', value: 11}],
      filteringForm: {
        Make: '',
        Model: '',
        Location: '',
        Mileage: '',
        Fuel: '',
        Transmission: '',
        Color: '',
        Doors: '',
        Seats: '',
        Power: '',
        Age: '',
        Body_type: '',
        Price_max: '',
        Price_min: ''
      }
    }
  },
  methods: {
    moreInfo (carItem) {
      this.$store.dispatch('storeCars', carItem)
      this.$router.push('/CarInfo')
    },
    searchWord () {
      if (this.keyword !== '') {
        axios
          .get(api + 'searchCar?Search=' + this.keyword)
          .then((response) => {
            console.log(response)
            this.allCars = response.data
            this.totalNumber = this.allCars.length
            this.numberCars = 10
            if (this.totalNumber < 10) {
              this.numberCars = this.totalNumber
            }
            this.cars = this.allCars.slice(0, this.numberCars)
          })
          .catch((error) => {
            console.log(error)
          })
      } else {
        this.getInitialCars()
      }
    },
    getInitialCars () {
      axios
        .get(api + 'showCar')
        .then((response) => {
          console.log(response)
          let selected = ['https://www.flexicar.es/media/default.jpg', 'https://www.flexicar.es/images/generic/coming_soon.jpg']
          let dict = response.data.reverse()
          let filtered = dict.filter(({Image}) => !selected.includes(Image))
          this.allCars = filtered.slice(0, 100)
          this.totalNumber = this.allCars.length
          this.cars = this.allCars.slice(0, this.numberCars)
        })
        .catch((error) => {
          console.log(error)
        })
    },
    getNextCars () {
      window.onscroll = () => {
        let bottomOfWindow = Math.round(document.documentElement.scrollTop + window.innerHeight) === document.documentElement.offsetHeight
        console.log(bottomOfWindow)
        if (bottomOfWindow) {
          let dif = this.totalNumber - this.numberCars
          if (dif >> 0) {
            var filtered2 = this.allCars.slice(this.numberCars, this.numberCars + 10)
            this.cars = this.cars.concat(filtered2)
            if (this.numberCars + 10 >> this.totalNumber) {
              this.numberCars = this.numberCars + 10
            } else {
              this.numberCars = this.totalNumber
            }
          }
        }
      }
    }
  },
  beforeMount () {
    this.getInitialCars()
  },
  mounted () {
    this.getNextCars()
  },
  watch: {
    filteringForm: {
      handler () {
        console.log('filteringForm changed')
        axios
          .post(api + 'filtering', this.filteringForm)
          .then((response) => {
            this.cars = response.data
            this.totalCars = response.data.length
          })
          .catch((error) => {
            console.log(error)
          })
      },
      deep: true
    }
  }
}

</script>
