<template>
  <div>
    <div style="color:white">{{location}}</div>
    <br>
    <GmapMap
      :center="center"
      :zoom="zoom"
      style="width: 450px; height: 300px"
    >
      <GmapMarker
        :key="index"
        v-for="(m, index) in markers"
        :position="m.position"
        :clickable="true"
        :draggable="true"
        @click="center=m.position"
      />
    </GmapMap>
  </div>
</template>

<script>

export default {
  name: 'LocationMap',
  props: ['location'],
  data () {
    if (this.location === 'Madrid') {
      return {
        center: {lat: 40.4168, lng: -3.7038},
        markers: [{
          position: {lat: 40.4168, lng: -3.7038}
        }],
        zoom: 10
      }
    } else if (this.location === 'Barcelona') {
      return {
        center: {lat: 41.3874, lng: 2.1686},
        markers: [{
          position: {lat: 41.3874, lng: 2.1686}
        }],
        zoom: 10
      }
    } else if (this.location === 'Pontevedra') {
      return {
        center: {lat: 42.4299, lng: -8.6446},
        markers: [{
          position: {lat: 42.4299, lng: -8.6446}
        }],
        zoom: 10
      }
    } else if (this.location === 'Valencia') {
      return {
        center: {lat: 39.4699, lng: -0.3763},
        markers: [{
          position: {lat: 39.4699, lng: -0.3763}
        }],
        zoom: 10
      }
    } else if (this.location === 'Islas Baleares') {
      return {
        center: {lat: 39.5342, lng: 2.8577},
        markers: [{
          position: {lat: 39.5342, lng: 2.8577}
        }],
        zoom: 10
      }
    } else if (this.location === 'Cadiz') {
      return {
        center: {lat: 36.5271, lng: -6.2886},
        markers: [{
          position: {lat: 36.5271, lng: -6.2886}
        }],
        zoom: 10
      }
    } else if (this.location === 'Malaga') {
      return {
        center: {lat: 36.7212, lng: -4.4217},
        markers: [{
          position: {lat: 36.7212, lng: -4.4217}
        }],
        zoom: 10
      }
    } else if (this.location === '>aragoza') {
      return {
        center: {lat: 41.6488, lng: -0.8891},
        markers: [{
          position: {lat: 41.6488, lng: -0.8891}
        }],
        zoom: 10
      }
    } else if (this.location === 'Cantabria') {
      return {
        center: {lat: 43.1828, lng: -3.9878},
        markers: [{
          position: {lat: 43.1828, lng: -3.9878}
        }],
        zoom: 10
      }
    } else if (this.location === 'Lugo') {
      return {
        center: {lat: 43.0097, lng: 7.5568},
        markers: [{
          position: {lat: 43.0097, lng: 7.5568}
        }],
        zoom: 10
      }
    } else if (this.location === 'Vizcaya') {
      return {
        center: {lat: 43.2204, lng: -2.6984},
        markers: [{
          position: {lat: 43.2204, lng: -2.6984}
        }],
        zoom: 10
      }
    } else if (this.location === 'Guadalajara') {
      return {
        center: {lat: 40.6325, lng: -3.1602},
        markers: [{
          position: {lat: 40.6325, lng: -3.1602}
        }],
        zoom: 10
      }
    } else if (this.location === 'Sevilla') {
      return {
        center: {lat: 37.3891, lng: -5.9845},
        markers: [{
          position: {lat: 37.3891, lng: -5.9845}
        }],
        zoom: 10
      }
    } else if (this.location === 'Toledo') {
      return {
        center: {lat: 39.8628, lng: -4.0273},
        markers: [{
          position: {lat: 39.8628, lng: -4.0273}
        }],
        zoom: 10
      }
    } else if (this.location === 'Ourense') {
      return {
        center: {lat: 42.3358, lng: -7.8639},
        markers: [{
          position: {lat: 42.3358, lng: -7.8639}
        }],
        zoom: 10
      }
    } else if (this.location === 'Murcia') {
      return {
        center: {lat: 37.9922, lng: -1.1307},
        markers: [{
          position: {lat: 37.9922, lng: -1.1307}
        }],
        zoom: 10
      }
    } else if (this.location === 'Burgos') {
      return {
        center: {lat: 42.3440, lng: -3.6969},
        markers: [{
          position: {lat: 42.3440, lng: -3.6969}
        }],
        zoom: 10
      }
    } else if (this.location === 'A Coruna') {
      return {
        center: {lat: 43.3623, lng: -8.4115},
        markers: [{
          position: {lat: 43.3623, lng: -8.4115}
        }],
        zoom: 10
      }
    } else if (this.location === 'Asturias') {
      return {
        center: {lat: 43.3614, lng: -5.8593},
        markers: [{
          position: {lat: 43.3614, lng: -5.8593}
        }],
        zoom: 10
      }
    } else if (this.location === 'Gerona') {
      return {
        center: {lat: 41.9794, lng: 2.8214},
        markers: [{
          position: {lat: 41.9794, lng: 2.8214}
        }],
        zoom: 10
      }
    } else if (this.location === 'Valladolid') {
      return {
        center: {lat: 41.6523, lng: -4.7245},
        markers: [{
          position: {lat: 41.6523, lng: -4.7245}
        }],
        zoom: 10
      }
    } else if (this.location === 'Badajoz') {
      return {
        center: {lat: 38.8794, lng: -6.9707},
        markers: [{
          position: {lat: 38.8794, lng: -6.9707}
        }],
        zoom: 10
      }
    } else if (this.location === 'Jaen') {
      return {
        center: {lat: 37.7796, lng: -3.7849},
        markers: [{
          position: {lat: 37.7796, lng: -3.7849}
        }],
        zoom: 10
      }
    } else if (this.location === 'Guipuzcoa') {
      return {
        center: {lat: 43.0756, lng: -2.2237},
        markers: [{
          position: {lat: 43.0756, lng: -2.2237}
        }],
        zoom: 10
      }
    } else if (this.location === 'Huesca') {
      return {
        center: {lat: 42.1318, lng: -0.4078},
        markers: [{
          position: {lat: 42.1318, lng: -0.4078}
        }],
        zoom: 10
      }
    } else if (this.location === 'Leon') {
      return {
        center: {lat: 42.5987, lng: -5.5671},
        markers: [{
          position: {lat: 42.5987, lng: -5.5671}
        }],
        zoom: 10
      }
    } else if (this.location === 'Alicante') {
      return {
        center: {lat: 38.346, lng: -0.4907},
        markers: [{
          position: {lat: 38.346, lng: -0.4907}
        }],
        zoom: 10
      }
    } else if (this.location === 'Huelva') {
      return {
        center: {lat: 37.2614, lng: -6.9447},
        markers: [{
          position: {lat: 37.2614, lng: -6.9447}
        }],
        zoom: 10
      }
    } else {
      return {
        center: {lat: 40, lng: 0},
        markers: [{
          position: {lat: 40, lng: 0}
        }],
        zoom: 10
      }
    }
  }
}
</script>
