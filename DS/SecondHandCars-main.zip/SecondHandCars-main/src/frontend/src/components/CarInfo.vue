<template>
  <div>
    <section id="content" style="border: 1px solid #ccc;display: flex; font-family: sans-serif;">
      <img alt="No image found" v-bind:src="stateCar.Image" style="max-width: 40%; height: 100%; vertical-align: middle;" @error="$event.target.src='https://www.3djuegos.com/files_foros/2k/2kfq.jpg'"/>

      <div style="padding: 20px;">
        <h2 style=" font-size: 24px; color: #222;line-height: 24px;"> <b> {{stateCar.Make}} </b> {{stateCar.Model}}</h2>
        <h3 style=" font-size: 24px; color: #222;line-height: 24px;margin-top:20px;"> <i> {{stateCar.Price}}€ </i></h3>
        <div style="border: 1px solid #179613; display: table; clear: both; padding:10px;margin-top:10px;height:100px;width:600px;">
          <div style="float:left;text-align: left;">
            <p>Location: {{stateCar.Location}}</p>
            <p>Mileage: {{stateCar.Mileage}} km</p>
            <p>Fuel: {{stateCar.Fuel}}</p>
          </div>
          <div style="float:left;margin-left:40px;text-align: left;">
            <p>Transmission: {{stateCar.Transmission}}</p>
            <p>Color: {{stateCar.Color}}</p>
            <p>Doors/Seats: {{stateCar.Doors}}/{{stateCar.Seats}}</p>
          </div>
          <div style="float:left;margin-left:40px;text-align: left;">
            <p>Power: {{stateCar.Power}}</p>
            <p>Age: {{stateCar.Age}}</p>
            <p>Body type: {{stateCar.Body_type}}</p>
          </div>
        </div>
      </div>

      <div style="margin-top:250px;width:300px;margin-left:-500px;margin-right:100px">
          <LocationMap :location=stateCar.Location />
      </div>

      <div style="margin-left:-800px;margin-top:350px;">
        <button @click.prevent="contact()" class="btn btn-success" type="submit">Contact with owner</button>
      </div>

    </section>

    <div style="margin-top:650px;padding:20px; display: flex;">
      <h2>Similar cars:</h2>
      <div id="articles" v-for="car in cars" :key="car.id" style="text-align: left; margin-left: 80px;">
        <div style="max-width: 130px;height: 130px;overflow: hidden;float: left;margin-right: 15px;border: 1px solid #ccc;">
          <img style="height:100%;text-align: center;"
            alt="No image found" @error="$event.target.src='https://www.3djuegos.com/files_foros/2k/2kfq.jpg'"
            v-bind:src="car.Image"/>
        </div>
        <h2 style="margin-bottom:-5px;">{{ car.Make }}</h2>
        <div><i>{{ car.Model }}</i></div>
        <div>
          {{ car.Price }} €
        </div>
        <button @click.prevent="moreInfo(car)" class="btn btn-success" type="submit" style="margin-top:10px;">More info +</button>
      </div>
    </div>
  </div>
</template>

<script>
import {mapState} from 'vuex'
import axios from 'axios'
import LocationMap from './LocationMap.vue'

// eslint-disable-next-line no-unused-vars
// let api = 'http://127.0.0.1:5000/'
// let api = 'https://secondhand-cars.herokuapp.com/'
let api = 'https://secondhand-cars-stage.herokuapp.com/'

export default {
  name: 'CarInfo',
  components: {
    LocationMap
  },
  data () {
    return {
      cars: [],
      length: {}
    }
  },
  computed: {
    ...mapState({stateCar: state => state.stateCar})
  },
  methods: {
    moreInfo (carItem) {
      this.$store.dispatch('storeCars', carItem)
      this.$router.push('/CarInfo')
      this.getSimilar()
    },
    getSimilar () {
      console.log('Buyer API')
      axios
        .post(api + 'buyer', this.stateCar)
        .then((response) => {
          console.log(response)
          console.log(typeof response.data)
          this.cars = response.data.slice(1, 6)
        })
        .catch((error) => {
          console.log(error)
        })
    },
    contact () {
      alert('Contact with owner: ' + '******@gmail.com' + '\n' + 'Phone: ' + '*********')
    }
  },
  mounted () {
    this.getSimilar()
  }
}
</script>
