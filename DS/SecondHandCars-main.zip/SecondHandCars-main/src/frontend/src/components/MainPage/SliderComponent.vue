<template>
  <div id="slider" class="slider-big">
    <h1>Welcome to SecondHandCars</h1>
    <router-link class="btn-white" href="#" to="/About">About us</router-link>
  </div>
</template>

<script>
export default {
  name: 'SliderComponent'
}
</script>
