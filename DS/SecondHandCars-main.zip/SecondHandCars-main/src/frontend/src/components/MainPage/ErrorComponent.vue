<template>
  <section id="content">
    <h1 class="subheader">Page Not Found</h1>
    <h2>The page you are looking for does not exist</h2>
  </section>
</template>

<script>
export default {
  name: 'ErrorComponent'
}
</script>
