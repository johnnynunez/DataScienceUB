<template>
  <div class="general">
    <div class="center">
      <section id="content">
        <p></p>
        <h3> "Your trusted AI second hand car scanner" </h3>
        <p>SHC is not an ordinary webpage of used cars. We are a data-driven company that incorporates machine learning
          techniques into all of our resources.  In SHC you can either find your desired car at the best price or get
          rid of your jalopy for a reasonable amount of money.</p>
        <p>One of our algorithms is responsible of providing a fair valuation for your car in line with your region’s
          market. In addition, you can also find out the location in which it is most profitable to make the sale and
          its appraisal.</p>
        <p>Moreover, the default order in which cars are displayed is by no means trivial.  We take advantage of our
          price estimator to show you the biggest bargains in first place. That is, cars that are being sold for a price
          inferior to its assessment. Furthermore, when we show similar cars, these are indeed similar, since they
          are obtained through clustering algorithms.</p>
        <p>Taking advantage of Artificial intelligent is what makes us different and better.</p>
        <i>This website is part of a project of the subject Data Agile, of the master in fundamentals of data science
          of the University of Barcelona and is directed by Dr. Eloi Puertas i Prats.</i>
        <p></p>
        <p></p>

        <h3> OUR TEAM </h3>
        <!--Listado articulos-->
        <div id="articles">
          <article id="article-template" class="article-item">
            <div class="image-wrap">
              <img
                alt="Car"
                src="https://avatars.githubusercontent.com/u/90788820?v=4"/>
            </div>
            <h4>Iñaki</h4>
            <span class="date">DS Analyst - ML - Vis</span>
            <a href="https://github.com/inakierregueab" target="_blank">Github Profile</a>
            <div class="clearfix"></div>
          </article>
          <article id="article-template" class="article-item">
            <div class="image-wrap">
              <img
                alt="Car"
                src="https://avatars.githubusercontent.com/u/82578262?v=4"/>
            </div>
            <h4>Pere</h4>
            <span class="date">ML - Data ENG</span>
            <a href="https://github.com/pere98diaz" target="_blank">Github Profile</a>
            <div class="clearfix"></div>
          </article>
          <article id="article-template" class="article-item">
            <div class="image-wrap">
              <img
                alt="Car"
                src="https://avatars.githubusercontent.com/u/37337655?v=4"/>
            </div>
            <h4>Pau</h4>
            <span class="date">DS Analyst - Data ENG</span>
            <a href="https://github.com/pasahe" target="_blank">Github Profile</a>
            <div class="clearfix"></div>
          </article>
          <article id="article-template" class="article-item">
            <div class="image-wrap">
              <img
                alt="Car"
                src="https://avatars.githubusercontent.com/u/92926736?v=4"/>
            </div>
            <h4>Oscar</h4>
            <span class="date">DS Analyst</span>
            <a href="https://github.com/oribeisa7" target="_blank">Github Profile</a>
            <div class="clearfix"></div>
          </article>
          <article id="article-template" class="article-item">
            <div class="image-wrap">
              <img alt="Car"
                   src="https://avatars.githubusercontent.com/u/92520420?v=4"/>
            </div>
            <h4>Robert</h4>
            <span class="date">DS Analyst - ML - Vis</span>
            <a href="https://github.com/RobertKrck" target="_blank">Github Profile</a>
            <div class="clearfix"></div>
          </article>
          <article id="article-template" class="article-item">
            <div class="image-wrap">
              <img
                alt="Car"
                src="https://avatars.githubusercontent.com/u/22727137?v=4"/>
            </div>
            <h4>Johnny</h4>
            <span class="date">FS - DEVOPS - QA</span>
            <a href="https://github.com/johnnync13" target="_blank">Github Profile</a>
            <div class="clearfix"></div>
          </article>
          <!--AÑADIR ARTICULOS VIA JS-->
        </div>
      </section>
    </div>
    <div class="center">
      <SidebarComponent></SidebarComponent>
      <div class="clearfix"></div>
    </div>
  </div>
</template>

<script>
import SliderComponent from './SliderComponent'
import SidebarComponent from './SidebarComponent'

export default {
  name: 'AboutComponent',
  components: {
    SliderComponent,
    SidebarComponent
  }
}
</script>
