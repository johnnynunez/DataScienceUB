<template>
  <section id="content">
    <div id='vizContainer'></div>
  </section>
</template>

<script>
export default {
  name: 'Dashboard',
  methods: {
    initViz () {
      const containerDiv = document.getElementById('vizContainer')

      let url = 'https://public.tableau.com/views/test2_16393432357700/Dashboard1'

      let options = {
        hideTabs: true,
        onFirstInteractive: () => {

        }
      }

      this.viz = new window.tableau.Viz(containerDiv, url, options)
    }
  },
  mounted () {
    this.initViz()
  }
}
</script>
