<template>
  <header id="header">
    <div class="center">
      <!-- LOGO -->
      <div id="logo">
        <img alt="Logotipo" class="app-logo" src="../../assets/images/vehicle.png"/>
        <span id="brand">
                        <strong>SecondHandCars</strong>
                    </span>
      </div>

      <!-- MENU -->
      <nav id="menu">
        <ul>
          <li>
            <router-link to="/Home">Home</router-link>
          </li>
          <li>
            <router-link to="/Buyer">Buy</router-link>
          </li>
          <li>
            <router-link to="/Seller">Sell</router-link>
          </li>
          <li>
            <router-link to="/Dashboard">Data Insights</router-link>
          </li>
          <li>
            <router-link to="/About">About Us</router-link>
          </li>

        </ul>
      </nav>

      <!--LIMPIAR FLOTADOS-->
      <div class="clearfix"></div>
    </div>
  </header>
</template>

<script>
export default {
  name: 'HeaderComponent'
}
</script>
