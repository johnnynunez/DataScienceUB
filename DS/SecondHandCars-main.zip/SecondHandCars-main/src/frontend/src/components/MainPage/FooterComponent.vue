<template>
  <footer id="footer">
    <div class="center">
      <p>
        &copy; SecondHandCars
      </p>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'FooterComponent'
}
</script>
