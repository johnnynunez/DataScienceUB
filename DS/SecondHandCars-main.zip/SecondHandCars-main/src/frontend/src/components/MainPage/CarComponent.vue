<template>
  <div class="general">
    <SliderComponent></SliderComponent>
    <div class="center">
      <section id="content">
        <p></p>
        <h6 class="subheader"> RECENTLY ADDED CARS </h6>
        <!--Listado articulos-->
        <div id="articles" v-for="car in cars" :key="car.id">
          <article id="article-template" class="article-item">
            <div class="image-wrap">
              <img
                alt="No image found" @error="$event.target.src='https://www.3djuegos.com/files_foros/2k/2kfq.jpg'"
                v-bind:src="car.Image"/>
            </div>
            <h2>{{ car.Make }}</h2>
            <div style="margin-top:-5px;font-style:italic;margin-bottom:10px;">{{ car.Model }}</div>
            <div style="font-weight:bold;font-size:15px;">
              {{ car.Price }} €
            </div>
            <br>
            <button @click.prevent="moreInfo(car)" class="btn btn-success" type="submit">More info +</button>
            <div class="clearfix"></div>
          </article>
        </div>
        <br>
        <i>Showing {{ numberCars }}/{{ totalNumber }} cars</i>
        <br>
        <br>
      </section>
    </div>
    <div class="center">
      <SidebarComponent></SidebarComponent>
      <aside id="sidebar">
        <div id="search" class="sidebar-item">
          <h3>Search engine</h3>
          <p>Find the car you are looking for</p>
          <form>
            <input v-model="keyword" name="search" type="text"/>
            <input @click.prevent="searchWord" class="btn" name="submit" type="submit" value="Search"/>
          </form>
        </div>
      </aside>
      <div class="clearfix"></div>
    </div>
  </div>
</template>

<script>

import SidebarComponent from './SidebarComponent'
import SliderComponent from './SliderComponent'
import axios from 'axios'

// eslint-disable-next-line no-unused-vars
// let api = 'http://127.0.0.1:5000/'
// let api = 'https://secondhand-cars.herokuapp.com/'
let api = 'https://secondhand-cars-stage.herokuapp.com/'

export default {
  name: 'CarComponent',
  components: {
    SliderComponent,
    SidebarComponent
  },
  data () {
    return {
      cars: [],
      allCars: [],
      readMore: {},
      numberCars: 10,
      totalNumber: '...',
      keyword: ''
    }
  },
  methods: {
    moreInfo (carItem) {
      this.$store.dispatch('storeCars', carItem)
      this.$router.push('/CarInfo')
    },
    searchWord () {
      if (this.keyword !== '') {
        axios
          .get(api + 'searchCar?Search=' + this.keyword)
          .then((response) => {
            console.log(response)
            this.allCars = response.data
            this.totalNumber = this.allCars.length
            this.numberCars = 10
            if (this.totalNumber < 10) {
              this.numberCars = this.totalNumber
            }
            this.cars = this.allCars.slice(0, this.numberCars)
          })
          .catch((error) => {
            console.log(error)
          })
      } else {
        this.getInitialCars()
      }
    },
    getInitialCars () {
      axios
        .get(api + 'showCar')
        .then((response) => {
          console.log(response)
          let selected = ['https://www.flexicar.es/media/default.jpg', 'https://www.flexicar.es/images/generic/coming_soon.jpg']
          let dict = response.data.reverse()
          let filtered = dict.filter(({Image}) => !selected.includes(Image))
          this.allCars = filtered.slice(0, 100)
          this.totalNumber = this.allCars.length
          this.cars = this.allCars.slice(0, this.numberCars)
        })
        .catch((error) => {
          console.log(error)
        })
    },
    getNextCars () {
      window.onscroll = () => {
        let bottomOfWindow = Math.round(document.documentElement.scrollTop + window.innerHeight) === document.documentElement.offsetHeight
        console.log(bottomOfWindow)
        if (bottomOfWindow) {
          let dif = this.totalNumber - this.numberCars
          if (dif >> 0) {
            var filtered2 = this.allCars.slice(this.numberCars, this.numberCars + 10)
            this.cars = this.cars.concat(filtered2)
            if (this.numberCars + 10 >> this.totalNumber) {
              this.numberCars = this.numberCars + 10
            } else {
              this.numberCars = this.totalNumber
            }
          }
        }
      }
    }
  },
  beforeMount () {
    this.getInitialCars()
  },
  mounted () {
    this.getNextCars()
  }
}

</script>
