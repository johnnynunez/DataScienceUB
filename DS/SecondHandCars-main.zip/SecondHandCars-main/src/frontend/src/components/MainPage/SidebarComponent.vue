<template>
  <aside id="sidebar">
    <div id="nav-blog" class="sidebar-item">
      <router-link class="btn btn-success" href="#" to="/AddCar">Sell your car</router-link>
    </div>
  </aside>
</template>

<script>

export default {
  name: 'SidebarComponent',
  data () {
    return {
      keyword: ''
    }
  }
}

</script>
