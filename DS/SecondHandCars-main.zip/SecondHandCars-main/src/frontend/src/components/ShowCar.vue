<template>
  <div class="general">
    <div class="center">
      <section id="content">
        <v-card>
          <h3 class="subheader">My Car</h3>
          <p>Make: {{ stateCar.Make }}</p>
          <p>Model: {{ stateCar.Model }}</p>
          <p>Location: {{ stateCar.Location }}</p>
          <p>Mileage: {{ stateCar.Mileage }}</p>
          <p>Fuel: {{ stateCar.Fuel }}</p>
          <p>Transmission: {{ stateCar.Transmission }}</p>
          <p>Color: {{ stateCar.Color }}</p>
          <p>Doors: {{ stateCar.Doors }}</p>
          <p>Seats: {{ stateCar.Seats }}</p>
          <p>Power: {{ stateCar.Power }}</p>
          <p>Age: {{ stateCar.Age }}</p>
          <p>Body_type: {{ stateCar.Body_type }}</p>
          <h3 class="subheader">Prediction</h3>
          <p>Prediction Price: {{ statePrediction.prediction }} €</p>
          <p>Lower Bound: {{ statePrediction.lower_bound }} €</p>
          <p>Upper Bound: {{ statePrediction.upper_bound }} €</p>
          <p></p>
          <v-btn color="success" @click="bestPlace()" value="request">Best Location</v-btn>
          <li v-for="(item, index) in this.bestLocation" :key="item">
            {{ index }}: {{ item }} €
          </li>
          <br>
          <p></p>
          <h3>Fill the form to sell your car</h3>
          <div class="form-group">
            <label for="Price">Price</label>
            <input id='Price' v-model="Price" name="Price" required type="text"/>
          </div>
          <div class="form-group">
            <label for="Location">Location</label>
            <input id='Location' v-model="Location" name="Location" required type="text"/>
          </div>
          <div class="form-group">
            <label for="Image">Image</label>
            <input id='Image' v-model="Image" name="Image URL" required type="url"/>
          </div>
          <div class="form-group">
            <label for="Email">Email</label>
            <input id='Email' name="Email" required type="text"/>
            <label for="Phone">Phone</label>
            <input id='Phone' name="Phone" required type="text"/>
          </div>
          <v-btn v-if="statePrediction.prediction !== ''" color="success" value="request" @click="addCar()">Add Car
          </v-btn>
        </v-card>
      </section>
    </div>
    <div class="center">
      <SidebarComponent></SidebarComponent>
      <div class="clearfix"></div>
    </div>
  </div>
</template>
<script>

import SidebarComponent from './MainPage/SidebarComponent'
import axios from 'axios'
import {mapState} from 'vuex'
import Vue from 'vue'

// eslint-disable-next-line no-unused-vars
// let api = 'http://127.0.0.1:5000/'
// let api = 'https://secondhand-cars.herokuapp.com/'
let api = 'https://secondhand-cars-stage.herokuapp.com/'

export default {
  name: 'ShowCar',
  components: {
    SidebarComponent
  },
  data () {
    return {
      bestLocation: [],
      CarCopy: '',
      Price: '',
      Image: '',
      Location: ''
    }
  },
  methods: {
    bestPlace () {
      this.CarCopy = {...this.stateCar}
      Vue.delete(this.CarCopy, 'Location')
      axios.post(api + '/best_location', this.CarCopy)
        .then((response) => {
          this.bestLocation = response.data
          console.log('locations: ' + this.bestLocation)
        })
        .catch((error) => {
          console.log(error)
        })
    },
    addCar () {
      this.CarCopy.Price = this.Price
      this.CarCopy.Image = this.Image
      this.CarCopy.Location = this.Location
      axios
        .post(api + 'addCar', this.CarCopy)
        .then((response) => {
          console.log(response)
          this.mensaje = response.data
          alert('You added a new car')
        })
        .catch((error) => {
          console.log(error)
          alert('Error to add a new car')
        })
    }
  },
  computed: {
    ...mapState({stateCar: state => state.stateCar, statePrediction: state => state.statePrediction})
  }
}
</script>
