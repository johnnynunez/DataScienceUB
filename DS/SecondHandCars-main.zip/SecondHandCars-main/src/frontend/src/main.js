// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router'
import {BootstrapVue, IconsPlugin} from 'bootstrap-vue'
import Vuetify from 'vuetify'
import router from './router'
import Vuex from 'vuex'
import store from './store'
import * as VueGoogleMaps from 'vue2-google-maps'

// import VueAxios from 'vue-axios'
import 'vuetify/dist/vuetify.min.css'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import colors from 'vuetify/lib/util/colors'

Vue.use(VueRouter)
Vue.use(BootstrapVue)
Vue.use(IconsPlugin)
Vue.use(Vuetify)
Vue.use(Vuex)

Vue.config.productionTip = false

Vue.use(VueGoogleMaps, {
  load: {
    key: 'AIzaSyCHANYO4sQXQcYKTsMe-rV6c8Y4dEcOqis',
    libraries: 'places'
  }
})

new Vue({
  el: '#app',
  router,
  store,
  vuetify: new Vuetify({
    theme: {
      themes: {
        light: {
          primary: colors.green.lighten2,
          secondary: colors.green.darken1,
          accent: colors.grey.darken3,
          error: colors.red.accent3,
          background: colors.white
        },
        dark: {
          primary: colors.green.lighten2,
          secondary: colors.green.darken1,
          accent: colors.grey.darken3,
          error: colors.red.accent3,
          background: colors.white
        }
      }
    }
  }),
  render: h => h(App)
}).$mount('#app')
