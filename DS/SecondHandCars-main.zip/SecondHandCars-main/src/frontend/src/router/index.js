import Vue from 'vue'
import Router from 'vue-router'

import CarComponent from '../components/MainPage/CarComponent'
import ErrorComponent from '../components/MainPage/ErrorComponent'
import SellerComponent from '../components/Seller'
import Buyer from '../components/Buyer'
import AddCar from '../components/AddCar'
import AboutComponent from '../components/MainPage/AboutComponent'
import ShowCar from '../components/ShowCar'
import Dashboard from '../components/MainPage/DashboardComponent'
import CarInfo from '../components/CarInfo'

Vue.use(Router)

const routes = [
  {path: '/Home', component: CarComponent},
  {path: '/About', name: 'AboutUs', component: AboutComponent},
  {path: '/Seller', component: SellerComponent},
  {path: '/Buyer', component: Buyer},
  {path: '/Dashboard', component: Dashboard},
  {path: '/AddCar', name: 'AddCar', component: AddCar},
  {path: '/ShowCar', component: ShowCar},
  {path: '/CarInfo', component: CarInfo},
  {path: '/', component: CarComponent},
  {path: '*', component: ErrorComponent}
]

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})
