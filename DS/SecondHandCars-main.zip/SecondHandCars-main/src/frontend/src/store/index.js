import Vuex from 'vuex'
import Vue from 'vue'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    stateCar: null,
    statePrediction: null
  },
  mutations: {
    'STORE_CAR' (state, carForm) {
      state.stateCar = carForm
      console.log('state=', state)
    },
    'STORE_PREDICTION' (state, prediction) {
      state.statePrediction = prediction
      console.log('state=', state)
    }
  },
  actions: {
    storeCars: ({commit}, carForm) => {
      console.log('STORE CAR', carForm)
      commit('STORE_CAR', carForm)
    },
    storePrediction: ({commit}, prediction) => {
      console.log('STORE PREDICTION', prediction)
      commit('STORE_PREDICTION', prediction)
    }
  },
  modules: {}
})
