<template>
  <div id="app">
    <v-app id="main" :style="{background: $vuetify.theme.themes[theme].background}">
    <HeaderComponent></HeaderComponent>
      <router-view></router-view>
      <FooterComponent></FooterComponent>
    </v-app>
  </div>
</template>

<script>
import HeaderComponent from './components/MainPage/HeaderComponent'

import CarComponent from './components/MainPage/CarComponent'
import FooterComponent from './components/MainPage/FooterComponent'
import HelloWorld from './components/MainPage/HelloWorld'
import AboutComponent from './components/MainPage/AboutComponent'
import ShowCar from './components/ShowCar'

export default {
  name: 'App',
  components: {
    HeaderComponent,
    CarComponent,
    FooterComponent,
    HelloWorld,
    AboutComponent,
    ShowCar
  },
  computed: {
    theme () {
      return (this.$vuetify.theme.dark) ? 'dark' : 'light'
    }
  }
}

</script>

<style>
/* #app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
} */

@import "./assets/css/styles.css";
</style>
