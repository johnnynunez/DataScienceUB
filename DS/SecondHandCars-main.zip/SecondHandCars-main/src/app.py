from decouple import config as config_decouple
from flask import Flask, render_template
from flask_cors import CORS
from flask_restful import Api

from config import config
from db import mongo
from resources.Algorithms.Buyer.deployment_buyer import Buyer
from resources.Algorithms.Buyer.filtering import Buyer_filtering
from resources.Algorithms.Seller.deployment_seller import Seller
from src.resources.Algorithms.Seller.BestLocation import Best_Location
from src.resources.Car.add_car import AddCar
from src.resources.Car.cars import Cars
from src.resources.Car.search_car import SearchCar
from src.resources.Car.show_car import ShowCar

app = Flask(__name__)
environment = config['development']

if config_decouple('STAGE', cast=bool, default=False):
    environment = config['stage']
elif config_decouple('PRODUCTION', cast=bool, default=False):
    environment = config['production']

app.config.from_object(environment)

# api initialization
api = Api(app)

# In this way, you are allowing access to Flask APP from outside
CORS(app, resources={r'/*': {'origins': '*'}})

"""migrate = Migrate()
db.init_app(app=app)
migrate.init_app(app, db)"""
mongo.init_app(app)

api.add_resource(Buyer, '/buyer')
api.add_resource(Seller, '/seller')
api.add_resource(AddCar, '/addCar')
api.add_resource(Best_Location, '/best_location')
api.add_resource(ShowCar, '/showCar')
api.add_resource(SearchCar, '/searchCar')
api.add_resource(Cars, '/cars')
api.add_resource(Buyer_filtering, '/filtering')


@app.route('/')
def render_vue():
    return render_template("index.html")


if __name__ == '__main__':
    app.run(port=5000, debug=True, threaded=False)
