"""from db import db

transmission = db.Table('transmission', db.Column('id', db.Integer, primary_key=True),
                        db.Column('transmission', db.String(100)))


class CarsModel(db.Model):
    __tablename__ = 'cars'

    id = db.Column(db.Integer, primary_key=True)
    make = db.Column(db.String(100), unique=False, nullable=False)
    km = db.Column(db.Float, nullable=False, unique=False)
    age = db.Column(db.Integer, nullable=False)
    fuel_type = db.Column(db.String(100), nullable=False)
    body_type = db.Column(db.String(100), nullable=False)
    color = db.Column(db.String(100), nullable=False)
    city = db.Column(db.String(100), nullable=False)
    power = db.Column(db.Integer, nullable=False)
    transmission = db.relationship("TransmissionModel", secondary=transmission)
    price = db.Column(db.Float, nullable=False)

    def __init__(self, make, km, age, fuel_type, body_type, color, city, power, transmission, price):
        self.make = make
        self.km = km
        self.age = age
        self.fuel_type = fuel_type
        self.body_type = body_type
        self.color = color
        self.city = city
        self.power = power
        self.transmission = transmission
        self.price = price

    @classmethod
    def find_by_id(cls, car_id):
        return db.session.query(cls).filter_by(id=car_id).first()

    @classmethod
    def find_by_make(cls, make):
        return db.session.query(cls).filter_by(make=make).first()

    @classmethod
    def find_by_km(cls, km):
        return db.session.query(cls).filter_by(km=km).first()

    @classmethod
    def find_by_age(cls, age):
        return db.session.query(cls).filter_by(age=age).first()

    @classmethod
    def find_by_fuel_type(cls, fuel_type):
        return db.session.query(cls).filter_by(fuel_type=fuel_type).first()

    @classmethod
    def find_by_body_type(cls, body_type):
        return db.session.query(cls).filter_by(body_type=body_type).first()

    @classmethod
    def find_by_color(cls, color):
        return db.session.query(cls).filter_by(color=color).first()

    @classmethod
    def find_by_city(cls, city):
        return db.session.query(cls).filter_by(city=city).first()

    @classmethod
    def find_by_power(cls, power):
        return db.session.query(cls).filter_by(power=power).first()

    @classmethod
    def find_by_transmission(cls, transmission):
        return db.session.query(cls).filter_by(transmission=transmission).first()

    @classmethod
    def find_by_price(cls, price):
        return db.session.query(cls).filter_by(price=price).first()

    @classmethod
    def get_all(cls):
        return db.session.query(cls).all()

    def save_to_db(self):
        db.session.add(self)
        db.session.commit()

    def delete_from_db(self):
        db.session.delete(self)
        db.session.commit()

    def json(self):
        return {
            'id': self.id,
            'make': self.make,
            'km': self.km,
            'age': self.age,
            'fuel_type': self.fuel_type,
            'body_type': self.body_type,
            'color': self.color,
            'city': self.city,
            'power': self.power,
            'transmission': [transmission.json() for transmission in self.transmission],
            'price': self.price
        }
"""
