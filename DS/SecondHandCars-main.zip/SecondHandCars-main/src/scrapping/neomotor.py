from time import sleep

from mongodb import upload_mongodb
from selenium import webdriver


def find_n_cars_neomotor(driver_path="/Users/mariateresaalvarez-buhillapuig/chromedriver"):
    browser = webdriver.Chrome(driver_path)
    browser.get("https://ocasion.neomotor.com")
    sleep(1)

    # TODO: search by 'provincia' if more date is needed

    accept_button = browser.find_element_by_xpath('//*[@id="didomi-notice-agree-button"]')
    accept_button.click()
    sleep(1)

    searcher = browser.find_element_by_xpath('// *[ @ id = "filtro-home"] / div / button')
    searcher.click()
    sleep(2)

    dic_cars = {}
    return dic_car


upload_mongodb(find_n_cars_neomotor())
