import json
import re
from pathlib import Path
from time import sleep

import numpy as np
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException


def find_n_cars_ooyyo(driver_path="C:/Users/psatorra/Downloads/chromedriver", n_pages=10):
    """
    Args:
        - driver_path
        - n_pages (int): number of pages to select (15 cars by page)

    Returns:
        - dic_cars (dict): {{},...}
    """
    # #dic_cars = []
    # First open the data that already has been scrapped:
    jsonpath = '../../data/raw_data/heycar.json'
    with open(jsonpath) as f:
        dic_cars = json.load(f)

    # Print length of dictionary:
    print(len(dic_cars))

    # Import add blocker:
    options = webdriver.ChromeOptions()
    options.add_extension('extension_3_11_2_0.crx')
    browser = webdriver.Chrome(driver_path, chrome_options=options)

    # Go to the cities link directly:
    browser.get("https://www.ooyyo.com/spain/used-cars-for-sale/c=CDA31D7114F1854F111BE56FAA651453/")
    sleep(4)

    # Close tab oppened for the installation of the add blocker and return to original tab with all the cars:
    # Switch to new tab oppened:
    tab_after = browser.window_handles[1]
    browser.switch_to.window(tab_after)
    browser.close()
    browser.switch_to.window(browser.window_handles[0])

    # Get all links:
    filter_city = browser.find_element_by_xpath('/html/body/section/div/div/ul[2]')
    cities = filter_city.find_elements_by_tag_name("li")

    # Keep the top 10 cities:
    cities = cities[1:10]
    cities = [city.find_element_by_tag_name("a") for city in cities]

    print(len(cities))

    for i in range(len(cities)):
        print(f'City {i + 1}: {cities[i].text}')

        cities[i].click()
        sleep(5)
        # Accept cookies (just the first time):
        if (i == 0):
            browser.find_element_by_xpath('//*[@id="qc-cmp2-ui"]/div[2]/div/button[2]').click()

        # Click to dismiss the popup it shows sometimes with download android application message:
        browser.find_element_by_xpath("//html").click()
        sleep(5)
        if (len(browser.window_handles) > 1):
            tab_after = browser.window_handles[1]
            browser.switch_to.window(tab_after)
            browser.close()
            browser.switch_to.window(browser.window_handles[0])

        for j in range(n_pages):
            print(f'Page: {j + 1}')

            cars = browser.find_elements_by_class_name('car-card-1')
            sleep(1)
            for k in range(len(cars)):
                # Select car:
                cars[k].click()
                sleep(2)
                # Switch to new tab oppened:
                tab_after = browser.window_handles[1]
                browser.switch_to.window(tab_after)
                # Keep all the features of the car selected and save them in a dictionary:
                try:
                    info = browser.find_element_by_xpath('/html/body/section/div[3]/div/div[2]/ul[1]').text + '\n'
                    info_list = re.findall(r'(.*)\n', info)
                    info_key = info_list[0::2]
                    info_val = info_list[1::2]
                    info_dic = dict(zip(info_key, info_val))
                    empty = {'Price': np.nan, 'Make': np.nan, 'Model': np.nan, 'Trim': np.nan, 'Mi': np.nan,
                             'Year': np.nan, 'Fuel type': np.nan, 'Body type': np.nan, 'Color': np.nan, 'City': np.nan,
                             'Power': np.nan, 'Transmission': np.nan}
                    new_car = [dict(empty, **info_dic)]
                    if new_car[0] not in dic_cars:
                        dic_cars += new_car

                    # Close tab oppened and return to original tab with all the cars:
                    browser.close()
                    browser.switch_to.window(browser.window_handles[0])

                except NoSuchElementException:
                    # Close tab oppened and return to original tab with all the cars:
                    print("Error")
                    browser.close()
                    browser.switch_to.window(browser.window_handles[0])

            # Click to next page when scrapping of all cars in the page has finished:
            if (j != 19):
                browser.find_element_by_xpath('/html/body/section/div[2]/div/div[6]/div/div/div/div[2]/a').click()

        jsonpath = Path(jsonpath)
        jsonpath.write_text(json.dumps(dic_cars))

        # Return to original page when finish one city:
        browser.get("https://www.ooyyo.com/spain/used-cars-for-sale/c=CDA31D7114F1854F111BE56FAA651453/")
        sleep(1)
        # Get again the link of the cities (doesn't work otherwise):
        filter_city = browser.find_element_by_xpath('/html/body/section/div/div/ul[2]')
        cities = filter_city.find_elements_by_tag_name("li")
        cities = cities[1:10]
        cities = [city.find_element_by_tag_name("a") for city in cities]

    return


find_n_cars_ooyyo(n_pages=20)
