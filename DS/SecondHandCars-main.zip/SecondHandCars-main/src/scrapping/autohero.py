from time import sleep

from mongodb import upload_mongodb
from selenium import webdriver


def find_n_cars_autohero(driver_path="/Users/mariateresaalvarez-buhillapuig/chromedriver"):
    browser = webdriver.Chrome(driver_path)
    browser.get("https://www.autohero.com/es/")
    sleep(1)

    accept_button = browser.find_element_by_xpath('/html/body/div[3]/div/form/div[2]/button[2]')
    accept_button.click()
    sleep(1)

    searcher = browser.find_element_by_xpath('//*[@id="app"]/div/main/div/div[1]/div/div/div/div/a')
    searcher.click()
    sleep(2)

    dic_cars = {}

    return dic_cars


upload_mongodb(find_n_cars_autohero())
