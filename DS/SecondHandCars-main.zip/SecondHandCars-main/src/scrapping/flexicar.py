import json
import re
import time
from pathlib import Path
from time import sleep

import numpy as np
from selenium import webdriver
from selenium.webdriver.common.keys import Keys


def find_flexicar(driver_path="C:/Users/psatorra/Downloads/chromedriver"):
    """
    Args:
        - driver_path

    Returns:
        - dic_cars (dict): {{},...}
    """

    # Import add blocker:
    options = webdriver.ChromeOptions()
    options.add_extension('extension_3_11_2_0.crx')
    browser = webdriver.Chrome(driver_path, chrome_options=options)

    # Initializate an empty dictionary:
    # dic_cars = []
    jsonpath = '../../data/raw_data/flexicar.json'
    with open(jsonpath) as f:
        dic_cars = json.load(f)

    print(f"Length of existing cars:{len(dic_cars)}")

    # Go to the link to scrap all cars:
    browser.get("https://www.flexicar.es/coches-segunda-mano/")
    sleep(4)

    # Close tab oppened for the installation of the add blocker and return to original tab with all the cars:
    # Switch to new tab oppened:
    tab_after = browser.window_handles[1]
    browser.switch_to.window(tab_after)
    browser.close()
    browser.switch_to.window(browser.window_handles[0])

    # load all cars (30 min)
    t_end = time.time() + 30 * 60
    while time.time() < t_end:
        browser.find_element_by_tag_name('html').send_keys(Keys.PAGE_DOWN)
        sleep(0.3)

    cars = browser.find_elements_by_class_name("col-sm-12.col-md-6.col-lg-4.coche")
    print(f"Cars found: {len(cars)}")
    for i in range(len(cars)):
        # Click on car and open in a new tab:
        link_car = cars[i].find_element_by_tag_name("a")
        link_car.send_keys(Keys.CONTROL + Keys.RETURN)
        sleep(1)
        # Switch to new tab oppened:
        browser.switch_to.window(browser.window_handles[1])
        sleep(1)
        info = browser.find_element_by_class_name('tab-content')
        info_list = re.findall(r'(.*)\n', info.text)
        info_key = info_list[0::2]
        info_val = info_list[1::2]
        info_dic = dict(zip(info_key, info_val))
        empty = {'Año': np.nan, 'Kilómetros': np.nan, 'Combustible': np.nan, 'Motor': np.nan, 'Cambio': np.nan,
                 'Color': np.nan, 'Puertas': np.nan, 'Plazas': np.nan}
        new_car = dict(empty, **info_dic)
        name = browser.find_element_by_class_name('col-sm-coche-right.boxcar')
        name = re.findall(r'(.*)\n', name.text)
        new_car['Make'] = name[0]
        new_car['Model'] = name[1]
        new_car['Price'] = browser.find_element_by_class_name('precio-new').text
        new_car['Location'] = browser.find_element_by_xpath('//*[@id="widget_"]/div/div[1]/div[1]').text
        new_car['Mileage'] = new_car.pop('Kilómetros')
        new_car['Fuel'] = new_car.pop('Combustible')
        new_car['Transmission'] = new_car.pop('Cambio')
        new_car['Color'] = new_car.pop('Color')
        new_car['Motor'] = new_car.pop('Motor')
        new_car['Doors'] = new_car.pop('Puertas')
        new_car['Seats'] = new_car.pop('Plazas')
        new_car['Year'] = new_car.pop('Año')
        new_car['Image'] = browser.find_element_by_xpath('//*[@id="galeria_fotos"]/div[1]/div[1]/img').get_attribute(
            "src")

        if new_car not in dic_cars:
            dic_cars += [new_car]

        # Control save:
        if i % 200 == 0:
            print(f'Iteration:{i}')
            jsonpath = '../../data/raw_data/new_flexicar.json'
            jsonpath = Path(jsonpath)
            jsonpath.write_text(json.dumps(dic_cars))

        browser.close()
        browser.switch_to.window(browser.window_handles[0])

    # Save at the end:
    jsonpath = '../../data/raw_data/new_flexicar.json'
    jsonpath = Path(jsonpath)
    jsonpath.write_text(json.dumps(dic_cars))

    return


find_flexicar()
