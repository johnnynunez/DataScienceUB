import json
import time
from time import sleep

import numpy as np
from selenium import webdriver
from selenium.webdriver.common.keys import Keys


def scrap_full_hrmotor(driver_path="chromedriver.exe"):
    browser = webdriver.Chrome(driver_path)
    browser.get("https://www.hrmotor.com/coches-segunda-mano")
    sleep(1)

    temp_list = []

    json_empty = False
    with open('hrmotor.json', 'r') as json_file:
        if not json_file.read(1):
            json_empty = True
    if json_empty:
        with open('hrmotor.json', 'w') as json_file:
            json.dump("[]", json_file)

    # load all cars
    t_end = time.time() + 30
    while time.time() < t_end:
        browser.find_element_by_tag_name('html').send_keys(Keys.PAGE_DOWN)
        sleep(0.1)

    cars = browser.find_elements_by_class_name("col-sm-6.col-md-4.coche")

    for i, car in enumerate(cars):
        if (i + 1) % 13 == 0:
            continue

        # open new tab
        link_div = browser.find_element_by_xpath('//*[@id="listado_coches"]/div[' + str(i + 1) + ']/div/a')
        link_div.send_keys(Keys.CONTROL + Keys.RETURN)
        browser.switch_to.window(browser.window_handles[1])

        try:
            complete_model = browser.find_element_by_xpath(
                '//*[@id="contenido"]/div[1]/section[2]/div[1]/div/h1').text
        except Exception as e:
            complete_model = "NAN"
        try:
            price = browser.find_element_by_xpath(
                '//*[@id="contenido"]/div[1]/section[2]/div[2]/div[2]/a/div[2]/div/span').text
        except Exception as e:
            price = np.nan
        try:
            image = browser.find_element_by_xpath('//*[@id="imagen_0"]/img').get_attribute('src')
        except Exception as e:
            image = "NAN"

        mileage = np.nan
        fuel = np.nan
        transmission = "NAN"
        horsepower = np.nan
        consumption = np.nan
        date = np.nan
        doors = np.nan
        seats = np.nan
        color = "NAN"
        location = "NAN"

        stats = browser.find_elements_by_class_name("col-xs-4.col-sm-3.minboxcontent")

        for stat in stats:
            try:
                [par, value] = stat.find_element_by_class_name("col-sm-7").text.split("\n", 1)
            except Exception as e:
                continue

            if par == "Kilómetros":
                mileage = value
            elif par == "Combustible":
                fuel = value
            elif par == "Cambio":
                transmission = value
            elif par == "Potencia":
                horsepower = value
            elif par == "Consumo":
                consumption = value
            elif par == "Matriculación":
                date = value
            elif par == "Puertas":
                doors = value
            elif par == "Plazas":
                seats = value
            elif par == "Color":
                color = value
            elif par == "Ubicación":
                location = value

        temp_list.append({"Model": complete_model,
                          "Price": price, "Location": location, "Date": date, "Mileage": mileage,
                          "Fuel": fuel, "Transmission": transmission, "Color": color,
                          "Doors": doors, "Seats": seats, "Power": horsepower, "Consumption": consumption,
                          "Image": image})

        if i % 100 == 0:
            with open('hrmotor.json', 'r') as json_file:
                full_list = json.load(json_file)
            with open('hrmotor.json', 'w') as json_file:
                for car in temp_list:
                    full_list.append(car)
                json.dump(full_list, json_file)
            temp_list = []

        # close tab
        parent = browser.window_handles[0]
        chld = browser.window_handles[1]
        browser.switch_to.window(chld)
        browser.close()
        browser.switch_to.window(parent)

    browser.close()

    with open('../../data/raw_data/hrmotor.json', 'r') as json_file:
        full_list = json.load(json_file)
    with open('../../data/raw_data/hrmotor.json', 'w') as json_file:
        for car in temp_list:
            full_list.append(car)
        json.dump(full_list, json_file)

    return


scrap_full_hrmotor()
