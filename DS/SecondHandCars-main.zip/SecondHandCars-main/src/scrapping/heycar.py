import json
from time import sleep

import numpy as np
from selenium import webdriver


def find_n_cars_heycar(driver_path="chromedriver.exe", n=100):
    browser = webdriver.Chrome(driver_path)
    browser.get("https://heycar.com/coches-segunda-mano?page=1")
    sleep(1)

    accept_button = browser.find_element_by_xpath('//*[@id="__next"]/div/div[2]/div/div/div/div[2]/button')
    accept_button.click()
    sleep(1)
    browser.find_element_by_xpath('//*[@id="__next"]/div/div[2]/div[1]/div[2]/div[4]/div[2]/div[2]/span[1]/a').click()

    temp_list = []

    for num_car in range(1, n + 1):
        sleep(1)

        try:
            [make, model] = browser.find_element_by_xpath(
                '//*[@id="__next"]/div/div[2]/div[1]/div[3]/div[2]/div[1]/span').text.split(" ", 1)
        except Exception as e:
            [make, model] = [np.nan, np.nan]
        try:
            complete_model = browser.find_element_by_xpath(
                '//*[@id="__next"]/div/div[2]/div[1]/div[3]/div[2]/div[1]/h6').text
        except Exception as e:
            complete_model = np.nan
        try:
            price = browser.find_element_by_xpath(
                '//*[@id="__next"]/div/div[2]/div[1]/div[3]/div[2]/div[2]/strong/div').text
        except Exception as e:
            price = np.nan
        try:
            date = browser.find_element_by_xpath('//*[@id="__next"]/div/div[2]/div[1]/div[4]/div/div[1]/span').text
        except Exception as e:
            date = np.nan
        try:
            mileage = browser.find_element_by_xpath('//*[@id="__next"]/div/div[2]/div[1]/div[4]/div/div[2]/span').text
        except Exception as e:
            mileage = np.nan
        try:
            fuel = browser.find_element_by_xpath('//*[@id="__next"]/div/div[2]/div[1]/div[4]/div/div[3]/span').text
        except Exception as e:
            fuel = np.nan
        try:
            transmission = browser.find_element_by_xpath(
                '//*[@id="__next"]/div/div[2]/div[1]/div[4]/div/div[4]/span').text
        except Exception as e:
            transmission = np.nan
        try:
            location = browser.find_element_by_xpath(
                '//*[@id="__next"]/div/div[2]/div[1]/div[3]/div[2]/div[3]/div[2]/div[2]/div[1]').text.split(", ")[-1]
        except Exception as e:
            location = np.nan
        try:
            color = browser.find_element_by_xpath(
                '//*[@id="__next"]/div/div[2]/div[1]/div[5]/div[1]/div[2]/div[2]/div').text
        except Exception as e:
            color = np.nan

        elements = browser.find_elements_by_class_name("sc-1s11sfy-0.icdHzJ")
        for i, element in enumerate(elements):
            sleep(.5)
            browser.execute_script("arguments[0].scrollIntoView();", element)
            element.click()
            if i == 1:
                break

        elements = browser.find_elements_by_class_name('lmj488-2.dLmKed')
        cc = None
        doors = None
        seats = None
        for i, element in enumerate(elements):
            try:
                text = element.text
                if "Cilindrada" in text:
                    elements2 = browser.find_elements_by_class_name('lmj488-3.kOyyXp')
                    for j, element2 in enumerate(elements2):
                        if j == i:
                            cc = element2.text
                if "Puertas" in text:
                    elements2 = browser.find_elements_by_class_name('lmj488-3.kOyyXp')
                    for j, element2 in enumerate(elements2):
                        if j == i:
                            doors = element2.text
                if "Asientos" in text:
                    elements2 = browser.find_elements_by_class_name('lmj488-3.kOyyXp')
                    for j, element2 in enumerate(elements2):
                        if j == i:
                            seats = element2.text
            except:
                continue
        if cc is None:
            cc = np.nan
        if doors is None:
            doors = np.nan
        if seats is None:
            seats = np.nan

        horsepower = None
        elements = browser.find_elements_by_class_name('lmj488-3.kOyyXp')
        for element in elements:
            try:
                text = element.text
                if "cv" in text:
                    horsepower = text
            except:
                continue
        if horsepower is None:
            horsepower = np.nan

        temp_list.append({"make": make, "model": model, "complete_model": complete_model,
                          "price": price, "location": location, "date": date, "mileage": mileage,
                          "fuel": fuel, "transmission": transmission, "color": color, "cc": cc,
                          "doors": doors, "seats": seats, "horsepower": horsepower})

        if num_car % 100 == 0:
            with open('raw_data/heycar.json', 'r') as json_file:
                full_list = json.load(json_file)
            with open('raw_data/heycar.json', 'w') as json_file:
                for car in temp_list:
                    full_list.append(car)
                json.dump(full_list, json_file)
            temp_list = []

        browser.find_element_by_xpath('//*[@id="__next"]/div/div[2]/div[1]/div[2]/div[2]/span[3]/img').click()

    browser.close()

    return


find_n_cars_heycar(n=18000)
