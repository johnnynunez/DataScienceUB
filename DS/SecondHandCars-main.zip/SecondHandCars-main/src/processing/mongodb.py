import json

import certifi
import pymongo


def upload_collection(cars_json, collection='CarsCollection'):
    try:
        if 'conn' in globals():
            conn.close()
            print("Closing")

        name = 'data_controller'
        password = 'TfyLDAdropxgGiLR'
        url = 'secondhandcars.p4jpe.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
        dbname = 'SecondHandCars'

        conn = pymongo.MongoClient("mongodb+srv://{}:{}@{}".format(name, password, url), tlsCAFile=certifi.where())

        print("Connected successfully!!!")

    except pymongo.errors.ConnectionFailure as e:
        print("Could not connect to MongoDB: %s" % e)

    db = conn[dbname]
    try:
        db.drop_collection(collection)
    except:
        pass

    _collection = db[collection]

    operations = [pymongo.operations.ReplaceOne(
        filter={"_id": doc["_id"]},
        replacement=doc,
        upsert=True
    ) for doc in json.loads(cars_json)]

    _collection.bulk_write(operations)
    return


def download_collection(collection='CarsCollection'):
    try:
        if 'conn' in globals():
            conn.close()
            print("Closing")

        name = 'data_controller'
        password = 'TfyLDAdropxgGiLR'
        url = 'secondhandcars.p4jpe.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
        dbname = 'SecondHandCars'

        conn = pymongo.MongoClient("mongodb+srv://{}:{}@{}".format(name, password, url), tlsCAFile=certifi.where())

        print("Connected successfully!!!")

    except pymongo.errors.ConnectionFailure as e:
        print("Could not connect to MongoDB: %s" % e)

    db = conn[dbname]
    _collection = db[collection]
    data = [car for car in _collection.find()]
    return data


def connect_to_mongo():
    try:
        if 'conn' in globals():
            conn.close()
            print("Closing")

        name = 'data_controller'
        password = 'TfyLDAdropxgGiLR'
        url = 'secondhandcars.p4jpe.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'

        conn = pymongo.MongoClient("mongodb+srv://{}:{}@{}".format(name, password, url), tlsCAFile=certifi.where())

        print("Connected successfully!!!")

    except pymongo.errors.ConnectionFailure as e:
        print("Could not connect to MongoDB: %s" % e)

    db = conn['SecondHandCars']
    return db


def search_engine_one_request(db, collection: str, request: dict) -> list:
    collection = db[collection]
    return [d for d in collection.find(request)]


def search_engine_many_requests(db, collection: str, request: list) -> list:
    collection = db[collection]
    return [d for d in collection.find({"_id": {"$in": request}})]
