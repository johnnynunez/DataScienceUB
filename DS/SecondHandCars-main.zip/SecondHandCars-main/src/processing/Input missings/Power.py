

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor, Pool
from sklearn.model_selection import KFold


from src.processing.mongodb import download_collection, upload_collection

pd.options.mode.chained_assignment = None

data = download_collection(collection='CarsCollectionNoMissings')

df = pd.DataFrame(data)
df_orig = df.copy()
df.drop(['_id', 'Doors', 'Seats', 'Color', 'Image'], axis=1, inplace=True)
df_noP = df[np.isnan(df['Power'])]
df_P = df[~np.isnan(df['Power'])]

y = df_P['Power']
X = df_P.drop('Power', axis=1)

X_p = df_noP.copy()
X_p.drop('Power', axis=1, inplace=True)


def RMSE(y, y_hat):
    return np.sqrt(np.mean((y - y_hat) ** 2))

"""
def grid_search(X, y, n_splits, dict_params):
    y = np.array(y)

    keys, values = zip(*dict_params.items())
    hyperparameters_list = [dict(zip(keys, v)) for v in itertools.product(*values)]
    skf = KFold(n_splits=n_splits, shuffle=True)
    skf.get_n_splits(X, y)

    # Categorical positions for catboost
    Categorical = list()
    for col in list(X):
        if X[col].dtypes == 'object':
            Categorical.append(col)

    Pos = list()
    for col in Categorical:
        Pos.append((X.columns.get_loc(col)))

    statistics = np.empty([len(hyperparameters_list), 3])
    stats_kfold = np.empty([len(hyperparameters_list), n_splits])

    j = 0

    for hyperparameters in hyperparameters_list:

        pred_hyper = np.empty(X.shape[0])
        stat_hyper = np.empty([n_splits])
        i = 0

        for train_index, test_index in skf.split(X, y):
            X_train, X_test = X.iloc[train_index, :], X.iloc[test_index, :]
            y_train, y_test = y[train_index], y[test_index]

            X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.20)

            pool_tr = Pool(X_train, y_train, cat_features=Pos)
            pool_val = Pool(X_val, y_val, cat_features=Pos)

            model_catboost = CatBoostRegressor(
                iterations=10000,  # Very high value, to find the optimum
                od_type='Iter',  # Overfitting detector set to "iterations"
                verbose=False)  # Shows train/test metric every "verbose" trees

            model_catboost.set_params(**hyperparameters)

            model_catboost.fit(X=pool_tr,
                               eval_set=pool_val,
                               early_stopping_rounds=100,
                               plot=False)

            y_test_hat = model_catboost.predict(X_test)
            pred_hyper[test_index] = y_test_hat

            stat_hyper[i] = RMSE(y_test, y_test_hat)
            stats_kfold[j, i] = stat_hyper[i]

            i = i + 1

        statistics[j, 0] = RMSE(y, pred_hyper)
        statistics[j, 1] = np.mean(stat_hyper)
        statistics[j, 2] = np.std(stat_hyper)

        j = j + 1

        print(str(j) + '/' + str(len(hyperparameters_list)))

    return statistics, hyperparameters_list, stats_kfold



params = {'objective': ['RMSE'],
          'depth': [4, 5],  # Depth of the trees (values betwwen 5 and 10, higher -> more overfitting)
          'l2_leaf_reg': [13, 14],  # L2 regularization (between 3 and 20, higher -> less overfitting)
          'rsm': [0.8],  # % of features to consider in each split (lower -> faster and reduces overfitting)
          'subsample': [0.7, 0.8],
          'bootstrap_type': ['MVS', 'Bernoulli']}

stat, hp_list, stats_general = grid_search(X=X, y=y, n_splits=5, dict_params=params)

for i in range(0, len(stat)):
    stat[i, 2] = np.std(stats_general[i])
    
stat_pd = pd.DataFrame(stat, columns = ['RMSE', 'mean_RMSE', 'STD'])

fdf = pd.DataFrame(hp_list).join(stat_pd)

fdf.sort_values('Mean absolute error', ascending=True)
"""
params = {'objective': 'RMSE',
          'depth': 5,  # Depth of the trees (values betwwen 5 and 10, higher -> more overfitting)
          'l2_leaf_reg': 14,  # L2 regularization (between 3 and 20, higher -> less overfitting)
          'rsm': 0.8,  # % of features to consider in each split (lower -> faster and reduces overfitting)
          'subsample': 0.7,
          'bootstrap_type': 'MVS'}

# Categorical positions for catboost
Categorical = list()
for col in list(X):
    if X[col].dtypes == 'object':
        Categorical.append(col)

Pos = list()
for col in Categorical:
    Pos.append((X.columns.get_loc(col)))

skf = KFold(n_splits=10, shuffle=True)
skf.get_n_splits(X, y)

y_miss_hat = np.zeros(X_p.shape[0])
y = np.array(y)

for train_index, val_index in skf.split(X, y):
    X_train, X_val = X.iloc[train_index, :], X.iloc[val_index, :]
    y_train, y_val = y[train_index], y[val_index]

    pool_tr = Pool(X_train, y_train, cat_features=Pos)
    pool_val = Pool(X_val, y_val, cat_features=Pos)

    model_catboost = CatBoostRegressor(iterations=10000, od_type='Iter', verbose=False)
    model_catboost.set_params(**params)

    model_catboost.fit(X=pool_tr,
                       eval_set=pool_val,
                       early_stopping_rounds=100,
                       plot=False)

    y_miss_hat = y_miss_hat + model_catboost.predict(X_p)

y_miss_hat_new = y_miss_hat / 10

df_orig.loc[np.isnan(df_orig['Power']), 'Power'] = y_miss_hat_new

df_orig_json = df_orig.to_json(orient='records')

upload_collection(df_orig_json, collection='CarsCollectionNoMissings')
