import itertools

import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from catboost import Pool
from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split

from src.processing.mongodb import download_collection

pd.options.mode.chained_assignment = None

data = download_collection(collection='CarsCollectionNoMissings')
df = pd.DataFrame(data)


def accuracy(y, y_hat):
    y_hat = np.rint(y_hat)
    e = np.count_nonzero(y_hat - y)
    acc = 1 - e / y_hat.shape[0]
    return acc


def split_data(X, y, frac=0.2, seed=None):
    if seed is not None:
        np.random.seed(seed)
    idx = np.arange(X.shape[0])
    idx_shuffled = np.random.permutation(idx)
    idx_shuffled_test = idx_shuffled[0:int(frac * len(idx_shuffled))]
    idx_shuffled_train = idx_shuffled[int(frac * len(idx_shuffled)): len(idx_shuffled)]
    X_train = X.iloc[idx_shuffled_train]
    X_test = X.iloc[idx_shuffled_test]
    y_train = y.iloc[idx_shuffled_train]
    y_test = y.iloc[idx_shuffled_test]
    return X_train, X_test, y_train, y_test


#  determine datasets

df["Seats"].replace({np.nan: "NAN"}, inplace=True)
df["Seats"] = df["Seats"].astype(str)

df_w_o_bt = df[df["Seats"] == "NAN"]
df_w_bt = df[df["Seats"] != "NAN"]

y = df_w_bt['Seats'].astype(float)
X = df_w_bt.drop(['_id', 'Color', 'Doors', 'Seats',
                  'Image'], axis=1)

params = {'depth': [7, 8, 9],
          'l2_leaf_reg': [4, 5]}


def grid_search(X, y, n_splits, dict_params):
    # Categorical positions for catboost
    Categorical = list()
    for col in list(X):
        if X[col].dtypes == 'object':
            Categorical.append(col)
    Pos = list()
    for col in Categorical:
        Pos.append((X.columns.get_loc(col)))

    # get hyperparameters
    keys, values = zip(*dict_params.items())
    hyperparameters_list = list()
    hyperparameters_list = [dict(zip(keys, v)) for v in itertools.product(*values)]
    best_param = pd.DataFrame(hyperparameters_list)

    # KFold
    skf = KFold(n_splits=n_splits, shuffle=True)

    statistics = np.empty([len(hyperparameters_list), 1])
    j = 0
    # search/train
    for hyperparameters in hyperparameters_list:
        pred_hyper = np.empty(X.shape[0])
        stat_hyper = np.empty([n_splits])

        i = 0
        for train_index, test_index in skf.split(X, y):
            # create test and validation sets
            X_train, X_test = X.iloc[train_index, :], X.iloc[test_index, :]
            y_train, y_test = y.iloc[train_index], y.iloc[test_index]
            X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.20)
            pool_tr = Pool(X_train, y_train, cat_features=Pos)
            pool_val = Pool(X_val, y_val, cat_features=Pos)

            model_catboost = CatBoostClassifier(
                objective='MultiClass',
                rsm=0.9,
                subsample=0.8,
                bootstrap_type='MVS',
                iterations=1000,
                od_type='Iter',  # Overfitting detector set to "iterations"
                verbose=False)  # Shows train/test metric every "verbose" trees
            model_catboost.set_params(**hyperparameters)
            model_catboost.fit(X=pool_tr,
                               eval_set=pool_val,
                               early_stopping_rounds=100,
                               plot=False)

            y_test_pred = model_catboost.predict(X_test)

            pred_hyper[test_index] = y_test_pred.reshape((y_test.shape[0]))

            stat_hyper[i] = accuracy(y_test_pred.reshape((y_test.shape[0])), y_test)
            i = i + 1
        statistics[j] = np.mean(stat_hyper)
        j = j + 1
    best_param['accuracy'] = statistics
    best_param.sort_values(by='accuracy', ascending=False, inplace=True)
    return hyperparameters_list, statistics, best_param


hyperparameters_list, statistics, best_param = grid_search(X, y, 5, params)

print(params)
print("best paramaeters:  ", " depth = ", best_param["depth"].iloc[0], " l2_leaf_reg = ",
      best_param["l2_leaf_reg"].iloc[0])
print("accuracy: ", best_param["accuracy"].iloc[0])
