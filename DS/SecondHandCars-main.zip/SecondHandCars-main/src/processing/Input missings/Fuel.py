import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from catboost import Pool
from sklearn.model_selection import train_test_split

from src.processing.mongodb import download_collection, upload_collection

pd.options.mode.chained_assignment = None
data = download_collection(collection='CarsCollectionNoMissings')

df = pd.DataFrame(data)
df["Fuel"].value_counts()
df_orig = df.copy()

df.drop(['_id', 'Doors', 'Seats', 'Color', 'Image'], axis=1, inplace=True)

df_noF = df[df['Fuel'] == 'NAN']
df_F = df[df['Fuel'] != 'NAN']

y = df_F['Fuel']
X = df_F.drop('Fuel', axis=1)
X_p = df_noF.drop('Fuel', axis=1)

# Categorical positions for catboost
Categorical = list()
for col in list(X):
    if X[col].dtypes == 'object':
        Categorical.append(col)

Pos = list()
for col in Categorical:
    Pos.append((X.columns.get_loc(col)))

params = {'objective': 'MultiClass',
          'depth': 4,  # Depth of the trees (values betwwen 5 and 10, higher -> more overfitting)
          'l2_leaf_reg': 16,  # L2 regularization (between 3 and 20, higher -> less overfitting)
          'rsm': 0.8,  # % of features to consider in each split (lower -> faster and reduces overfitting)
          'subsample': 0.8,
          'bootstrap_type': 'MVS'}

"""Execute the following code only to check performance on a test dataset. Otherwise
train with the whole dataset"""

"""
X_model, X_ts, y_model, y_ts = train_test_split(X, y, test_size=0.20, stratify=y)
X_model.reset_index(drop=True, inplace=True)



X_tr, X_vl, y_tr, y_vl = train_test_split(X_model, y_model, test_size=0.20, stratify=y_model)

pool_tr=Pool(X_tr, y_tr, cat_features=Pos)
pool_vl=Pool(X_vl, y_vl, cat_features=Pos)
    
Catboost_Model = CatBoostClassifier(
        iterations=10000,
        od_type='Iter',
        verbose=500,
        )
Catboost_Model.set_params(**params)
Catboost_Model.fit(X=pool_tr,
                       eval_set=pool_vl,
                       early_stopping_rounds=100,
                       plot=False)

y_ts_pred = Catboost_Model.predict(X_ts)

res = pd.DataFrame([np.squeeze(y_ts_pred), y_ts]).T
res.columns = ['Pred', 'Real']
accuracy = 1-res[res['Pred'] != res['Real']].shape[0]/res[res['Pred'] == res['Real']].shape[0]
print("Accuracy of {}".format(accuracy))
"""

X_tr, X_vl, y_tr, y_vl = train_test_split(X, y, test_size=0.20, stratify=y)

pool_tr = Pool(X_tr, y_tr, cat_features=Pos)
pool_vl = Pool(X_vl, y_vl, cat_features=Pos)

Catboost_Model = CatBoostClassifier(
    iterations=10000,
    od_type='Iter',
    verbose=500,
)

Catboost_Model.set_params(**params)

Catboost_Model.fit(X=pool_tr,
                   eval_set=pool_vl,
                   early_stopping_rounds=100,
                   plot=False)

df_orig.loc[df_orig['Fuel'] == 'NAN', 'Fuel'] = np.squeeze(Catboost_Model.predict(X_p))
df_orig_json = df_orig.to_json(orient='records')
upload_collection(df_orig_json, collection='CarsCollectionNoMissings')
