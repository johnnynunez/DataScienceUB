import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from catboost import Pool

from src.processing.mongodb import download_collection, upload_collection

pd.options.mode.chained_assignment = None

data = download_collection(collection='CarsCollectionNoMissings')
df = pd.DataFrame(data)


def split_data(X, y, frac=0.2, seed=None):
    if seed is not None:
        np.random.seed(seed)
    idx = np.arange(X.shape[0])
    idx_shuffled = np.random.permutation(idx)
    idx_shuffled_test = idx_shuffled[0:int(frac * len(idx_shuffled))]
    idx_shuffled_train = idx_shuffled[int(frac * len(idx_shuffled)): len(idx_shuffled)]
    X_train = X.iloc[idx_shuffled_train]
    X_test = X.iloc[idx_shuffled_test]
    y_train = y.iloc[idx_shuffled_train]
    y_test = y.iloc[idx_shuffled_test]
    return X_train, X_test, y_train, y_test


#  determine datasets

df["Doors"].replace({np.nan: "NAN"}, inplace=True)
# copy for uploading
df_orig = df.copy()
df["Doors"] = df["Doors"].astype(str)

df_w_o_bt = df[df["Doors"] == "NAN"]
df_w_bt = df[df["Doors"] != "NAN"]

y = df_w_bt['Doors']
X = df_w_bt.drop(['_id', 'Color', 'Doors', 'Image'], axis=1)
# data for which we want to fill the missings:
X_p = df_w_o_bt.drop(['_id', 'Color', 'Doors', 'Image'], axis=1)

"""
X_train, X_test, y_train, y_test = split_data(X, y)
X_train, X_val, y_train, y_val = split_data(X_train, y_train)

# Categorical positions for catboost
Categorical = list()
for col in list(X_train):
    if X_train[col].dtypes == 'object':
        Categorical.append(col)

Pos = list()
for col in Categorical:
    Pos.append((X_train.columns.get_loc(col)))

pool_tr = Pool(X_train, y_train, cat_features=Pos)
pool_vl = Pool(X_test, y_test, cat_features=Pos)

#class_weights = {'2.0': 100 / y_train[y_train == '2.0'].shape[0],
#                 '3.0': 100 / y_train[y_train == '3.0'].shape[0],
#                 '4.0': 100 / y_train[y_train == '4.0'].shape[0],
#                 '5.0': 100 / y_train[y_train == '5.0'].shape[0],
#                 '7.0': 100 / y_train[y_train == '7.0'].shape[0],
#                 '9.0': 100 / y_train[y_train == '9.0'].shape[0]}

params = {'objective': 'MultiClass',
          'depth': 8,  # Depth of the trees (values betwwen 5 and 10, higher -> more overfitting)
          'l2_leaf_reg': 4,  # L2 regularization (between 3 and 20, higher -> less overfitting)
          'rsm': 0.9,  # % of features to consider in each split (lower -> faster and reduces overfitting)
          'subsample': 0.8,
          'bootstrap_type': 'MVS'}

Catboost_Model = CatBoostClassifier(
    iterations=1000,
    od_type='Iter',
    verbose=False,)
    #class_weights=class_weights)

Catboost_Model.set_params(**params)

Catboost_Model.fit(X=pool_tr,
                   eval_set=pool_vl,
                   early_stopping_rounds=400,
                   plot=False)

y_test_pred_prop = np.squeeze(Catboost_Model.predict(X_test))
y_test_pred_prop = y_test_pred_prop.astype(float)
y_test = y_test.astype(float)

def error(y, y_hat):
    y_hat = np.rint(y_hat)
    e = np.count_nonzero(y_hat - y)
    acc = 1 - e / y_hat.shape[0]

    return acc

error(y_test_pred_prop, y_test)
"""

X_train, X_val, y_train, y_val = split_data(X, y)

# Categorical positions for catboost
Categorical = list()
for col in list(X_train):
    if X_train[col].dtypes == 'object':
        Categorical.append(col)

Pos = list()
for col in Categorical:
    Pos.append((X_train.columns.get_loc(col)))

pool_tr = Pool(X_train, y_train, cat_features=Pos)
pool_vl = Pool(X_val, y_val, cat_features=Pos)

params = {'objective': 'MultiClass',
          'depth': 8,  # Depth of the trees (values betwwen 5 and 10, higher -> more overfitting)
          'l2_leaf_reg': 4,  # L2 regularization (between 3 and 20, higher -> less overfitting)
          'rsm': 0.9,  # % of features to consider in each split (lower -> faster and reduces overfitting)
          'subsample': 0.8,
          'bootstrap_type': 'MVS'}

Catboost_Model = CatBoostClassifier(
    iterations=1000,
    od_type='Iter',
    verbose=500)
# class_weights=class_weights)

Catboost_Model.set_params(**params)

Catboost_Model.fit(X=pool_tr,
                   eval_set=pool_vl,
                   early_stopping_rounds=400,
                   plot=False)

# updating the data
df_orig.loc[df_orig['Doors'] == 'NAN', 'Doors'] = np.squeeze(Catboost_Model.predict(X_p))
df_orig['Doors'] = df_orig['Doors'].astype(float)
df_orig_json = df_orig.to_json(orient='records')
upload_collection(df_orig_json, collection='CarsCollectionNoMissings')
