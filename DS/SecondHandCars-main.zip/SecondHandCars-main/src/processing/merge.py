import json

import numpy as np
import pandas as pd
import unidecode

from src.processing.mongodb import upload_collection

# load data
heycar = pd.read_json('../../data/transformed_data/heycar_transformed.json')
ooyyo = pd.read_json('../../data/transformed_data/ooyyo_transformed.json')
hrmotor = pd.read_json('../../data/transformed_data/hrmotor_transformed.json')
flexicar = pd.read_json('../../data/transformed_data/flexicar_transformed.json')

# merge
df = pd.concat([heycar, ooyyo, hrmotor, flexicar], ignore_index=True, sort=False)

# Delete accents
df['Make'] = df['Make'].apply(unidecode.unidecode)

# Labels check
df['Make'] = df['Make'].str.replace(r'(smart)', 'Smart', regex=True)
df['Make'] = df['Make'].str.replace(r'(CUPRA)', 'Cupra', regex=True)
df['Make'] = df['Make'].str.replace(r'(MINI)', 'Mini', regex=True)
df['Make'] = df['Make'].str.replace(r'(Bmw)', 'BMW', regex=True)
df['Make'] = df['Make'].str.replace(r'(Mercedes Benz)', 'Mercedes-Benz', regex=True)
df['Make'] = df['Make'].str.replace(r'(Ds Automobiles)', 'DS', regex=True)
df['Make'] = df['Make'].str.replace(r'(Alfa)$', 'Alfa Romeo', regex=True)
df['Make'] = df['Make'].str.replace(r'(Alfa Romeo Romeo)', 'Alfa Romeo', regex=True)

df['Location'] = df['Location'].str.replace(r'(Recogida donde tu elijas)', 'NAN', regex=True)
df['Location'] = df['Location'].str.replace(r'(La Coruna)', 'A Coruna', regex=True)
df['Location'] = df['Location'].str.replace(r'(Lerida)', 'Lleida', regex=True)

df['Transmission'] = df['Transmission'].str.replace(r'(Semi Automatic)', 'Semiautomatic', regex=True)

df['Fuel'] = df['Fuel'].str.replace(r'(Autogas)', 'Gas', regex=True)

df['Color'] = df['Color'].str.replace(r'(Plateado)', 'Silver', regex=True)
df['Color'] = df['Color'].str.replace(r'(Bronse)', 'Bronze', regex=True)
df.loc[df['Color'].str.contains('Gray', case=False), 'Color'] = 'Grey'

# TODO: model check

# float casting
df['Price'] = df['Price'].astype('float')
df['Mileage'] = df['Mileage'].astype('float')
df['Capacity'] = df['Capacity'].astype('float')
df['Doors'] = df['Doors'].astype('float')
df['Seats'] = df['Seats'].astype('float')
df['Power'] = df['Power'].astype('float')
df['Age'] = df['Age'].astype('float')

# categorical UFT8 casting and fillna for CatBoost
categorical_var = df.select_dtypes(include='O').columns
for column in categorical_var:
    df[column] = df[column].fillna('NAN').apply(unidecode.unidecode)

# Change name
df.rename(columns={'Body type': 'Body_type'}, inplace=True)

# Make index
df.reset_index(drop=True, inplace=True)
df['_id'] = df.index
df = df[~np.isnan(df['Price'])]
df = df[df['Location'] != 'NAN']
df["Fuel"].replace({"Other": "NAN", "Etanol": "NAN"}, inplace=True)
df.drop(['Capacity', 'Consumption'], axis=1, inplace=True)
df["Doors"].replace({7: 5}, inplace=True)
df["Seats"].replace({0: np.nan}, inplace=True)
df = df[df['Make'] != "NAN"]

with open('car_model_correction.json') as f:
    car_model_correction = json.load(f)

df["Model"].replace(car_model_correction, inplace=True)

#df = df[~df['_id'].isin([610, 1581, 1575, 392, 1550, 1315, 294, 67])]
df = df[df['Price']<500000]
df['Power'].replace({1500: 150})
df = df[~df['_id'].isin([363, 4552])]

# export
data = df.to_json(orient='records')

with open("../../data/transformed_data/training_set.json", "w") as file:
    json.dump(data, file)

upload_collection(data, collection='CarsCollection')
