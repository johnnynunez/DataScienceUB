import json
from datetime import date

import numpy as np
import pandas as pd
import unidecode

# load data
df = pd.read_json('../../data/raw_data/hrmotor.json', convert_dates=False)

# float casting
df['Price'] = df['Price'].str.replace(r'\D+', '', regex=True).astype('float')
df['Mileage'] = df['Mileage'].str.replace(r'\D+', '', regex=True).astype('float')


# compute age of car
def age(born):
    today = date.today()
    return today.year - born.year


df['Date'] = pd.to_datetime(df['Date'], format='%Y')
df['Age'] = df['Date'].apply(age)
df.drop(columns=['Date'], inplace=True)

# clean 'Seats' errors and cast to float
df['Seats'] = df['Seats'].str.replace(r'\D+', '', regex=True)
df['Seats'] = df['Seats'].replace(r'^\s*$', np.nan, regex=True)
df['Seats'] = df['Seats'].fillna(value=np.nan).astype('float')

# categorical UFT8 casting and fillna for CatBoost
categorical_var = df.select_dtypes(include='O').columns
for column in categorical_var:
    df[column] = df[column].fillna('NAN').apply(unidecode.unidecode)

# float fillna for CatBoost
numerical_var = df.select_dtypes(include='float').columns
for column in numerical_var:
    df[column] = df[column].fillna(np.nan)

# split make from model
new_df = df.iloc[424:]
new_df[['Make', 'Model']] = new_df[df['Make'] == 'NAN']['Model'].str.split(n=1, expand=True)
df.drop(df.index[424:], inplace=True)
df = pd.concat([df, new_df])

# labels check
df['Make'] = df['Make'].str.replace(r'(Mercedes)$', 'Mercedes-Benz', regex=True)
df['Make'] = df['Make'].str.replace(r'(DS5)', 'DS', regex=True)
df['Make'] = df['Make'].str.replace(r'(DS7)', 'DS', regex=True)
df['Make'] = df['Make'].str.replace(r'(C4)', 'Citroen', regex=True)
df['Make'] = df['Make'].str.replace(r'(Chrevrolet)', 'Chevrolet', regex=True)
df['Make'] = df['Make'].str.replace(r'(ALFA)', 'Alfa Romeo', regex=True)
df['Make'] = df['Make'].str.replace(r'(SEAT)', 'Seat', regex=True)
df['Make'] = df['Make'].str.replace(r'(TOYOTA)', 'Toyota', regex=True)
df['Make'] = df['Make'].str.replace(r'(AUDI)', 'Audi', regex=True)
df['Make'] = df['Make'].str.replace(r'(JAGUAR)', 'Jaguar', regex=True)
df['Make'] = df['Make'].str.replace(r'(Discovery)', 'Land Rover', regex=True)
df['Make'] = df['Make'].str.replace(r'(Land)$', 'Land Rover', regex=True)

df['Location'] = df['Location'].str.replace(r'(12 meses)', 'NAN', regex=True)
df['Location'] = df['Location'].str.replace(r'(Tudela)', 'Navarra', regex=True)
df['Location'] = df['Location'].str.replace(r'(Pamplona)', 'Navarra', regex=True)
df['Location'] = df['Location'].str.replace(r'(Collado-Villalba)', 'Madrid', regex=True)

df['Fuel'] = df['Fuel'].str.replace(r'(Electrico)', 'Electric', regex=True)
df['Fuel'] = df['Fuel'].str.replace(r'(Hibrido Gasolina)', 'Hybrid', regex=True)
df['Fuel'] = df['Fuel'].str.replace(r'(Hibrido \(Diesel\))', 'Hybrid', regex=True)
df['Fuel'] = df['Fuel'].str.replace(r'(Gasolina)', 'Petrol', regex=True)
df['Fuel'] = df['Fuel'].str.replace(r'(Otro)', 'Other', regex=True)
df['Fuel'] = df['Fuel'].str.replace(r'(GLP)', 'Gas', regex=True)

df['Transmission'] = df['Transmission'].str.replace(r'(Automatico)', 'Automatic', regex=True)
df['Transmission'] = df['Transmission'].str.replace(r'(Secuencial)', 'Sequential', regex=True)

df['Color'] = df['Color'].str.replace(r'(Blanco)', 'White', regex=True)
df['Color'] = df['Color'].str.replace(r'(Azul claro)', 'Blue', regex=True)
df['Color'] = df['Color'].str.replace(r'(Azul)', 'Blue', regex=True)
df['Color'] = df['Color'].str.replace(r'(Gris/Plata)$', 'Gray', regex=True)
df['Color'] = df['Color'].str.replace(r'(Gris claro)$', 'Gray', regex=True)
df['Color'] = df['Color'].str.replace(r'(Gris-negro)$', 'Gray', regex=True)
df['Color'] = df['Color'].str.replace(r'(Gris)', 'Gray', regex=True)
df['Color'] = df['Color'].str.replace(r'(Plateado)', 'Silver', regex=True)
df['Color'] = df['Color'].str.replace(r'(Plata)', 'Silver', regex=True)
df['Color'] = df['Color'].str.replace(r'(Rojo)', 'Red', regex=True)
df['Color'] = df['Color'].str.replace(r'(Negro)', 'Black', regex=True)
df['Color'] = df['Color'].str.replace(r'(Verde)', 'Green', regex=True)
df['Color'] = df['Color'].str.replace(r'(Oro)', 'Gold', regex=True)
df['Color'] = df['Color'].str.replace(r'(Naranja)', 'Orange', regex=True)
df['Color'] = df['Color'].str.replace(r'(Amarillo)', 'Yellow', regex=True)
df['Color'] = df['Color'].str.replace(r'(Marron)', 'Brown', regex=True)
df['Color'] = df['Color'].str.replace(r'(Bronce)', 'Bronze', regex=True)
df['Color'] = df['Color'].str.replace(r'(Granate)', 'Garnet', regex=True)
df['Color'] = df['Color'].str.replace(r'(Violeta/Lila)', 'Purple', regex=True)

df['Color'] = df['Color'].str.replace(r'(Sevilla)', 'NAN', regex=True)
df['Color'] = df['Color'].str.replace(r'(Valencia)', 'NAN', regex=True)
df['Color'] = df['Color'].str.replace(r'(Alicante)', 'NAN', regex=True)
df['Color'] = df['Color'].str.replace(r'(Madrid)', 'NAN', regex=True)
df['Color'] = df['Color'].str.replace(r'(Bilbao)', 'NAN', regex=True)
df['Color'] = df['Color'].str.replace(r'(Barcelona)', 'NAN', regex=True)
df['Color'] = df['Color'].str.replace(r'(Tudela)', 'NAN', regex=True)
df['Color'] = df['Color'].str.replace(r'(Pamplona)', 'NAN', regex=True)
df['Color'] = df['Color'].str.replace(r'(Zaragoza)', 'NAN', regex=True)
df['Color'] = df['Color'].str.replace(r'(Salamanca)', 'NAN', regex=True)
df['Color'] = df['Color'].str.replace(r'(Oscuro)', 'NAN', regex=True)
df['Color'] = df['Color'].str.replace(r'(Collado-Villalba)', 'NAN', regex=True)

df['Model'] = df['Model'].str.replace(r'(Benz )', '', regex=True)
df['Model'] = df['Model'].str.replace(r'(Benz )', '', regex=True)
df['Model'] = df['Model'].str.replace(r'(Romeo )', '', regex=True)
df['Model'] = df['Model'].str.replace(r'(Rover )', '', regex=True)

def first2_word(st):
    value = 0
    words = st.split(' ')
    if len(words) >= 2:
        value = words[0] + ' ' + words[1]
    elif len(words) == 1:
        value = words[0]
    else:
        print('wtf')
    return value

categorical_var = df.select_dtypes(include='O').columns
for column in categorical_var:
    df[column] = df[column].fillna('NAN').apply(unidecode.unidecode)

df['Model'] = df['Model'].apply(first2_word)

# delete duplicates
df.drop_duplicates(inplace=True)

# export
data = df.to_dict('records')

with open("../../data/transformed_data/hrmotor_transformed.json", "w") as file:
    json.dump(data, file)
