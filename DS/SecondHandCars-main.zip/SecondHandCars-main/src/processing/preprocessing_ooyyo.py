import datetime
import json

import numpy as np
import pandas as pd
import pgeocode
from geopy.geocoders import Nominatim

# load data
data = pd.read_json('../../data/raw_data/ooyyo.json')

# changing mismatched columns
data.at[221, 'Color'] = "Silver"
data.at[221, 'Body type'] = "Crossover"
data.at[221, 'City'] = "El Prat De Llobregat"
data.at[221, 'Transmission'] = np.nan
data.at[221, 'Power'] = '177 kW (241 HP)'

data.at[268, 'Color'] = "Green"
data.at[268, 'Body type'] = "Suv"
data.at[268, 'City'] = "El Prat De Llobregat"
data.at[268, 'Transmission'] = np.nan
data.at[268, 'Power'] = "150 kW (204 HP)"

# drop duplicates
data.drop(data[data.duplicated()].index, inplace=True)

# Price
data = data[data["Price"] != "..."]
data["Price"] = data["Price"].str.strip("EUR").str.strip().str.replace(',', '')
data["Price"] = data["Price"].astype(int)

# Mi
data["Mi"] = data["Mi"].str.strip("km").str.strip().str.replace(',', '').astype(float)

# Year
now = datetime.datetime.now()
data["Year"] = now.year - data["Year"].astype(int)
data["Year"] = data["Year"].astype(int)

# Power
data["Power"] = data["Power"].str.split()
data["Power"] = (data["Power"].str[2])
data["Power"] = data["Power"].str[1:]
data["Power"].replace({"one": "NaN"}, inplace=True)
data["Power"] = data["Power"].astype(float)

# rename columns
data = data.rename(
    columns={'City': 'Location', "Year": "Age", "Mi": "Mileage", 'Fuel type': 'Fuel', "Body type": "Body_type"})

# drop useless columns
data.drop(["Trim", "Euro norm"], axis=1,
          inplace=True)  # Trim is hard to be informative and Euro norm has too few values

# fill NaN's with NAN for categorial features (Fuel type, Transmission, Color)
values = {"Transmission": "Automatic"}
data.fillna(value=values, inplace=True)
data.fillna("NAN", inplace=True)

# - location -

# initialize Nominatim API
geolocator = Nominatim(user_agent="geoapiExercises")
# instantiate a new Nominatim client
app = Nominatim(user_agent="tutorial")


# function to find postcode of the province for given name

def postcode(name, count=0):
    if count == 10:
        print("no postcode")
        return 0
    # get location and transform to df
    location = app.geocode(name, country_codes="es").raw
    df = pd.DataFrame(location)
    # extracting lat and long
    lat, long = df["lat"][0], df["lon"][0]
    # get adress from lat and long
    addr = geolocator.reverse(lat + "," + long).raw["address"]
    # print(addr)
    if "postcode" in addr:
        return addr["postcode"]
    elif "province" in addr and name != addr["province"]:
        return postcode(addr["province"], count + 1)
    elif "region" in addr and name != addr["region"]:
        return postcode(addr["region"], count + 1)
    elif "state_district" in addr and name != addr["state_district"]:
        return postcode(addr["state_district"], count + 1)
    elif "county" in addr and name != addr["county"]:
        return postcode(addr["county"], count + 1)
    elif "village" in addr and name != addr["village"]:
        return postcode(addr["village"], count + 1)
    else:
        print("nothing found")
        return 1


# create dataframe for the city - postcode
dic = {}
for i in data["Location"].unique():
    s = postcode(i)
    if s != 0 and s != 1:
        dic[i] = [s]
    else:
        print(i)
dic = pd.DataFrame.from_dict(dic)

# create dataframe for postcode - province
nomi = pgeocode.Nominatim('es')
dic2 = {}
l = 0
for i in dic.iloc[0]:
    dic2[l] = [nomi.query_postal_code(i)["county_name"]]
    l = l + 1
dic2 = pd.DataFrame.from_dict(dic2)

# create dataframe city - province
new_df = dic2.set_axis(list(dic.columns.values), axis=1)

# create new column in data with province
data["Location"] = list(new_df[data["Location"]].transpose()[0])

# transform format
df = data.to_dict('records')

# export
with open("../../data/transformed_data/ooyyo_transformed.json", "w") as file:
    json.dump(df, file)
