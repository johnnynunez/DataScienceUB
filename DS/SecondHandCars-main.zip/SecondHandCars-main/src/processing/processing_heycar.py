import json
from datetime import date

import pandas as pd
import unidecode

# load data
df = pd.read_json('../../data/raw_data/heycar.json')

# float casting
df['price'] = df['price'].str.replace(r'\D+', '', regex=True).astype('float')
df['mileage'] = df['mileage'].str.replace(r'\D+', '', regex=True).astype('float')
df['cc'] = df['cc'].str.replace(r'\D+', '', regex=True).astype('float')
df['horsepower'] = df['horsepower'].str.replace(r'\D+', '', regex=True).astype('float')


# compute age of car
def age(born):
    today = date.today()
    return today.year - born.year


df['date'] = pd.to_datetime(df['date'], format='%Y-%m-%d')
df['Age'] = df['date'].apply(age)
df.drop(columns=['date'], inplace=True)

# Delete accents
df['make'] = df['make'].apply(unidecode.unidecode)
df['model'] = df['model'].apply(unidecode.unidecode)
df['complete_model'] = df['complete_model'].apply(unidecode.unidecode)
df['location'] = df['location'].apply(unidecode.unidecode)
df['fuel'] = df['fuel'].apply(unidecode.unidecode)
df['transmission'] = df['transmission'].apply(unidecode.unidecode)
df['color'] = df['color'].fillna('Other')
df['color'] = df['color'].apply(unidecode.unidecode)

# Duplicated location (different languages)
df['location'] = df['location'].str.replace(r'(Vizkaya)', 'Vizcaya', regex=True)
df['location'] = df['location'].str.replace(r'(Bizkaia)', 'Vizcaya', regex=True)
df['location'] = df['location'].str.replace(r'(Castello)', 'Castellon', regex=True)
df['location'] = df['location'].str.replace(r'(Castellonn)', 'Castellon', regex=True)

# Translate to english
df['fuel'] = df['fuel'].str.replace(r'(Electrico)', 'Electric', regex=True)
df['fuel'] = df['fuel'].str.replace(r'(Gasolina)', 'Petrol', regex=True)
df['fuel'] = df['fuel'].str.replace(r'(Hibrido)', 'Hybrid', regex=True)
df['fuel'] = df['fuel'].str.replace(r'(Otro)', 'Other', regex=True)
df['transmission'] = df['transmission'].str.replace(r'(Automatico)', 'Automatic', regex=True)
df['transmission'] = df['transmission'].str.replace(r'(Semiautomatico)', 'Semiautomatic', regex=True)
df['color'] = df['color'].str.replace(r'(Blanco)', 'White', regex=True)
df['color'] = df['color'].str.replace(r'(Azul)', 'Blue', regex=True)
df['color'] = df['color'].str.replace(r'(Gris)', 'Gray', regex=True)
df['color'] = df['color'].str.replace(r'(Platedo)', 'Silver', regex=True)
df['color'] = df['color'].str.replace(r'(Rojo)', 'Red', regex=True)
df['color'] = df['color'].str.replace(r'(Negro)', 'Black', regex=True)
df['color'] = df['color'].str.replace(r'(Verde)', 'Green', regex=True)
df['color'] = df['color'].str.replace(r'(Otro)', 'Other', regex=True)
df['color'] = df['color'].str.replace(r'(Naranja)', 'Orange', regex=True)
df['color'] = df['color'].str.replace(r'(Amarillo)', 'Yellow', regex=True)
df['color'] = df['color'].str.replace(r'(Marron)', 'Brown', regex=True)

# delete complete_model
df.drop(columns='complete_model', inplace=True)

# delete duplicates
df.drop_duplicates(inplace=True)

# rename features
mapping = {'make': 'Make', 'model': 'Model', 'price': 'Price', 'location': 'Location', 'mileage': 'Mileage',
           'fuel': 'Fuel', 'transmission': 'Transmission', 'color': 'Color', 'cc': 'Capacity', 'doors': 'Doors',
           'seats': 'Seats', 'horsepower': 'Power'}
df.rename(columns=mapping, inplace=True)

# export
data = df.to_dict('records')

with open("../../data/transformed_data/heycar_transformed.json", "w") as file:
    json.dump(data, file)
