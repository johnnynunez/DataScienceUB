import json
from datetime import date

import numpy as np
import pandas as pd
import unidecode

# load data
df = pd.read_json('../../data/raw_data/flexicar.json', convert_dates=False)

# Split motor and power
df[['Motor', 'Power']] = df['Motor'].str.split(pat='/', expand=True)

# float casting
df['Price'] = df['Price'].str.replace(r'\D+', '', regex=True).astype('float')
df['Mileage'] = df['Mileage'].str.replace(r'\D+', '', regex=True).astype('float')
df['Year'] = df['Year'].str.replace(r'\D+', '', regex=True).astype('float')
df['Power'] = df['Power'].str.replace(r'\D+', '', regex=True).astype('float')
df['Doors'] = df['Doors'].astype('float')
df['Seats'] = df['Seats'].astype('float')


# compute age of car
def age(born):
    today = date.today()
    return today.year - born.year


df['Year'] = pd.to_datetime(df['Year'], format='%Y')
df['Age'] = df['Year'].apply(age).astype('float')
df.drop(columns=['Year'], inplace=True)

# drop complete model and motor
df.drop(columns=['Model', 'Motor'], inplace=True)

# fill na and cast
categorical_var = df.select_dtypes(include='O').columns
for column in categorical_var:
    df[column] = df[column].fillna('NAN').apply(unidecode.unidecode)

numerical_var = df.select_dtypes(include='float').columns
for column in numerical_var:
    df[column] = df[column].fillna(np.nan)


# get model from make
def last_word(st):
    last = st.rsplit(None, 1)[-1]
    return last


def first_word(st):
    last = st.split(' ', 1)[0]
    return last


df['Model'] = df['Make'].apply(last_word)

df['Make'] = df['Make'].apply(first_word)

# adjust labels
df['Make'] = df['Make'].str.replace(r'(SEAT)', 'Seat', regex=True)
df['Make'] = df['Make'].str.replace(r'(Land)$', 'Land Rover', regex=True)
df['Make'] = df['Make'].str.replace(r'(Mercedes)$', 'Mercedes-Benz', regex=True)

df['Transmission'] = df['Transmission'].str.replace(r'(manual)', 'Manual', regex=True)
df['Transmission'] = df['Transmission'].str.replace(r'(Automatica)', 'Automatic', regex=True)
df['Transmission'] = df['Transmission'].str.replace(r'(automatica)', 'Automatic', regex=True)

df['Fuel'] = df['Fuel'].str.replace(r'(Electrico)', 'Electric', regex=True)
df['Fuel'] = df['Fuel'].str.replace(r'(Hibrido)', 'Hybrid', regex=True)
df['Fuel'] = df['Fuel'].str.replace(r'(Gasolina)', 'Petrol', regex=True)
df['Fuel'] = df['Fuel'].str.replace(r'(GLP)', 'Gas', regex=True)

df['Location'] = df['Location'].str.replace(r'\d+', '', regex=True)
df['Location'] = df['Location'].str.replace(r'(Autosmadrid Alcala)|(Leganes)|(Alcala de Henares)'
                                            , 'Madrid', regex=True)
df['Location'] = df['Location'].str.replace(r'(AutosMadrid)|(Mostoles)|(Alcorcon)|(San Fernando de Henares)'
                                            , 'Madrid', regex=True)
df['Location'] = df['Location'].str.replace(r'(Fuenlabrada)|(Las Rozas)|(Aravaca)|(Toledo)'
                                            , 'Madrid', regex=True)
df['Location'] = df['Location'].str.replace(r'(Rivas Vaciamadrid )', 'Madrid', regex=True)
df['Location'] = df['Location'].str.replace(r'(Rivas Vaciamadrid)|(Alcobendas)|(San Sebastian de los Reyes)',
                                            'Madrid', regex=True)
df['Location'] = df['Location'].str.replace(r'(Hospitalet de Llobregat)|(Mataro)|(Badalona)',
                                            'Barcelona', regex=True)
df['Location'] = df['Location'].str.replace(r'(Esplugues de Llobregat)|(Sabadell)|(Viladecans)|(Granollers)',
                                            'Barcelona', regex=True)
df['Location'] = df['Location'].str.replace(r'(Xativa)', 'Castellon', regex=True)
df['Location'] = df['Location'].str.replace(r'\s$', '', regex=True)

df.loc[df['Color'].str.contains('Rojo', case=False), 'Color'] = 'Red'
df.loc[df['Color'].str.contains('Red', case=False), 'Color'] = 'Red'
df.loc[df['Color'].str.contains('Rosso', case=False), 'Color'] = 'Red'
df.loc[df['Color'].str.contains('Blanco', case=False), 'Color'] = 'White'
df.loc[df['Color'].str.contains('White', case=False), 'Color'] = 'White'
df.loc[df['Color'].str.contains('Bianco', case=False), 'Color'] = 'White'
df.loc[df['Color'].str.contains('Gris', case=False), 'Color'] = 'Grey'
df.loc[df['Color'].str.contains('Grey', case=False), 'Color'] = 'Grey'
df.loc[df['Color'].str.contains('Grigio', case=False), 'Color'] = 'Grey'
df.loc[df['Color'].str.contains('Gray', case=False), 'Color'] = 'Grey'
df.loc[df['Color'].str.contains('Negro', case=False), 'Color'] = 'Black'
df.loc[df['Color'].str.contains('Black', case=False), 'Color'] = 'Black'
df.loc[df['Color'].str.contains('Plata', case=False), 'Color'] = 'Silver'
df.loc[df['Color'].str.contains('Plateado', case=False), 'Color'] = 'Silver'
df.loc[df['Color'].str.contains('Silver', case=False), 'Color'] = 'Silver'
df.loc[df['Color'].str.contains('Amarillo', case=False), 'Color'] = 'Yellow'
df.loc[df['Color'].str.contains('Yellow', case=False), 'Color'] = 'Yellow'
df.loc[df['Color'].str.contains('Azul', case=False), 'Color'] = 'Blue'
df.loc[df['Color'].str.contains('Blue', case=False), 'Color'] = 'Blue'
df.loc[df['Color'].str.contains('Cyan', case=False), 'Color'] = 'Blue'
df.loc[df['Color'].str.contains('Blau', case=False), 'Color'] = 'Blue'
df.loc[df['Color'].str.contains('Blu', case=False), 'Color'] = 'Blue'
df.loc[df['Color'].str.contains('Verde', case=False), 'Color'] = 'Green'
df.loc[df['Color'].str.contains('Green', case=False), 'Color'] = 'Green'
df.loc[df['Color'].str.contains('Marron', case=False), 'Color'] = 'Brown'
df.loc[df['Color'].str.contains('Brown', case=False), 'Color'] = 'Brown'
df.loc[df['Color'].str.contains('Beige', case=False), 'Color'] = 'Beige'
df.loc[df['Color'].str.contains('Bronce', case=False), 'Color'] = 'Bronze'
df.loc[df['Color'].str.contains('Bronze', case=False), 'Color'] = 'Bronze'
df.loc[df['Color'].str.contains('naranja', case=False), 'Color'] = 'Orange'
df.loc[df['Color'].str.contains('orange', case=False), 'Color'] = 'Orange'
df.loc[df['Color'].str.contains('mandarina', case=False), 'Color'] = 'Orange'
df.loc[df['Color'].str.contains('oro', case=False), 'Color'] = 'Gold'
df.loc[df['Color'].str.contains('gold', case=False), 'Color'] = 'Gold'
df.loc[df['Color'].str.contains('purple', case=False), 'Color'] = 'Purple'
df.loc[df['Color'].str.contains('lila', case=False), 'Color'] = 'Purple'
df.loc[df['Color'].str.contains('morado', case=False), 'Color'] = 'Purple'
df.loc[df['Color'].str.contains('violeta', case=False), 'Color'] = 'Purple'
df.loc[df['Color'].str.contains('metal', case=False), 'Color'] = 'Metal'
df.loc[df['Color'].str.contains('REVISAR', case=False), 'Color'] = 'NAN'
df.loc[df['Color'].str.contains('Color solido a elegir', case=False), 'Color'] = 'NAN'
df.loc[df['Color'].str.contains('Pintura personalizada Audi exclusive', case=False), 'Color'] = 'NAN'
df.loc[df['Color'].str.contains('LAVAGRAU PERLEFFEKT', case=False), 'Color'] = 'NAN'

# delete duplicates
df.drop_duplicates(inplace=True)

# export
data = df.to_dict('records')

with open("../../data/transformed_data/flexicar_transformed.json", "w") as file:
    json.dump(data, file)
