import os

from decouple import config

basedir = os.path.abspath(os.path.dirname(__file__))


class Config:
    pass


class ProductionConfig(Config):
    DEBUG = False
    # SQLALCHEMY_DATABASE_URI = config('DATABASE_URL', default='https://secondhand-cars.herokuapp.com/')
    # SQLALCHEMY_TRACK_MODIFICATIONS = False
    MONGO_URI = config('MONGO_URI',
                       default='mongodb+srv://heroku:A7vjOo8lss97fh5O@secondhandcars.p4jpe.mongodb.net/SecondHandCars?retryWrites=true&w=majority')
    STATIC_FOLDER = "/static"
    TEMPLATE_FOLDER = "/templates"
    SECRET_KEY = config('SECRET_KEY', default='A7vjOo8lss97fh5O')


class StageConfig(Config):
    DEBUG = False
    # SQLALCHEMY_DATABASE_URI = config('DATABASE_URL', default='https://secondhand-cars-stage.herokuapp.com/')
    # SQLALCHEMY_TRACK_MODIFICATIONS = False
    MONGO_URI = config('MONGO_URI',
                       default='mongodb+srv://heroku:A7vjOo8lss97fh5O@secondhandcars.p4jpe.mongodb.net/SecondHandCars?retryWrites=true&w=majority')
    STATIC_FOLDER = "/static"
    TEMPLATE_FOLDER = "/templates"
    SECRET_KEY = config('SECRET_KEY', default='A7vjOo8lss97fh5O')


class DevelopmentConfig(Config):
    DEBUG = True
    # SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'data.db')
    # SQLALCHEMY_TRACK_MODIFICATIONS = False
    MONGO_URI = config('MONGO_URL',
                       default='mongodb+srv://heroku:A7vjOo8lss97fh5O@secondhandcars.p4jpe.mongodb.net/SecondHandCars?retryWrites=true&w=majority')
    STATIC_FOLDER = "/frontend/dist/static"
    TEMPLATE_FOLDER = "/frontend/dist"
    SECRET_KEY = "A7vjOo8lss97fh5O"


config = {
    'development': DevelopmentConfig,
    'stage': StageConfig,
    'production': ProductionConfig
}
