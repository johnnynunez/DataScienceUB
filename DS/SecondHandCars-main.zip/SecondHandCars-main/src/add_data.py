from decouple import config as config_decouple
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

from config import config

app = Flask(__name__)
environment = config['development']
if config_decouple('PRODUCTION', cast=bool, default=False):
    environment = config['production']
app.config.from_object(environment)

db = SQLAlchemy(app)
app.app_context().push()

meta = db.metadata
for table in reversed(meta.sorted_tables):
    print("add_data> Clearing table %s" % table)
    db.session.execute(table.delete())
db.session.commit()

db.session.commit()
db.session.close()
exit()
