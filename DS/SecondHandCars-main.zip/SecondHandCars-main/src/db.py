"""from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
"""
from flask_pymongo import PyMongo

mongo = PyMongo()
db = mongo.db
