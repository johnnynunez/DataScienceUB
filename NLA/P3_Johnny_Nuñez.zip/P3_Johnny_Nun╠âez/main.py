import time
import numpy as np
import scipy.sparse as sp
from scipy.io import mmread
from scipy.sparse.linalg import spsolve
from scipy.sparse.linalg import eigs
import time
G = mmread('p2p-Gnutella30.mtx')
G = sp.csr_matrix(G)
print(G.todense())

n = G.shape[0]


def GtoA(G):
    init_time = time.perf_counter()
    d = np.sum(G, axis=0)
    # d = sp.csr_matrix.sum(G, axis=0)
    d[d == 0] = 1
    d = np.squeeze(np.asarray(np.divide(1, d)))
    D = sp.diags(d)
    x = np.dot(G, D)
    end_time = time.perf_counter()
    print("Time to convert G to A: ", end_time - init_time)
    return x


def power(A, tol=1e-9, m=0.15):
    init_time = time.perf_counter()
    xk = np.ones((n, 1))
    d = np.sum(A, axis=0)
    z = np.where(d != 0, m / n, 1 / n)
    e = np.ones((n, 1))
    xk1 = np.ones((n, 1)) / n
    while np.linalg.norm(xk1 - xk, np.inf) > tol:
        xk = xk1
        xk1 = (1 - m) * A.dot(xk) + e * z.dot(xk)
    x = xk / np.sum(xk)
    end_time = time.perf_counter()
    print("Time to compute power method: ", end_time - init_time)
    return x


A = GtoA(G)

# print(power(A))


def generate_L(G):
    init_time = time.perf_counter()
    d = dict()
    rows = G.nonzero()[0]
    cols = G.nonzero()[1]

    for j in range(len(cols)):
        i = cols[j]
        if i in d:
            d[i] = np.append(d[i], rows[j])
        else:
            d[i] = np.asarray([rows[j]])

    end_time = time.perf_counter()
    print("time generate L", end_time - init_time)
    return d


def power2(G, tol=1e-9, m=0.15):
    init_time = time.perf_counter()
    L = generate_L(G)

    x = np.ones(n)
    xc = np.ones(n) + 9

    while np.linalg.norm(xc - x, np.inf) > tol:
        xc = x
        x = np.zeros(n)
        for j in range(n):
            if j in L:
                k = L[j]
                x[k] += xc[j] / len(k)
            else:
                x += xc[j] / n
        x = (1 - m) * x + m / n
    end_time = time.perf_counter()
    print("time power 2", end_time - init_time)
    return x


print(power2(G, tol=1e-9, m=0.15))


